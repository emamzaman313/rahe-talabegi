# بستهٔ منبع حقیقت هم‌قدم

- `docs/SOURCE-OF-TRUTH-PROMPT.txt`: نسخهٔ کامل ابرپرامپت ارائه‌شده، بدون تغییر محتوا.
- `docs/IMPLEMENTATION-ROADMAP.md`: نقشهٔ مرحله‌بندی اجرا؛ مکمل پرامپت است و جایگزین آن نیست.

## مقصد پیشنهادی در مخزن
مخزن: `nagshe-negar/rahe-talabegi`
مسیرهای پیشنهادی: `docs/SOURCE-OF-TRUTH-PROMPT.txt` و `docs/IMPLEMENTATION-ROADMAP.md`

پس از بارگذاری، در README اصلی به این دو فایل پیوند بده و `docs/REQUIREMENTS-STATUS.md` را بعد از هر مرحله با نتیجهٔ واقعی تست‌ها به‌روزرسانی کن.

**وضعیت بارگذاری:** هنوز در GitHub ثبت نشده است. اتصال GitHub در نشست فعلی عملیات نوشتن را با HTTP 403 رد کرده؛ این بسته صرفاً آمادهٔ بارگذاری است و نباید به‌عنوان commit انجام‌شده معرفی شود.
