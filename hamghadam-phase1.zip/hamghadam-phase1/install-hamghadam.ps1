$ErrorActionPreference = 'Stop'
$packageFiles = Join-Path $PSScriptRoot 'files'
if (-not (Test-Path -LiteralPath $packageFiles -PathType Container)) {
  throw "Package files directory not found: $packageFiles"
}
$repoRoot = if ($env:GITHUB_WORKSPACE) { $env:GITHUB_WORKSPACE } else { (Get-Location).Path }

Get-ChildItem -LiteralPath $packageFiles -File -Recurse -Force | ForEach-Object {
  $relative = [System.IO.Path]::GetRelativePath($packageFiles, $_.FullName)
  $target = Join-Path $repoRoot $relative
  $targetDirectory = Split-Path -Parent $target
  New-Item -ItemType Directory -Path $targetDirectory -Force | Out-Null
  Copy-Item -LiteralPath $_.FullName -Destination $target -Force
  Write-Host "Installed: $relative"
}

$indexPath = Join-Path $repoRoot 'index.html'
if (-not (Test-Path -LiteralPath $indexPath -PathType Leaf)) {
  throw 'index.html was not found; refusing to finish without wiring the new module.'
}
$index = Get-Content -LiteralPath $indexPath -Raw -Encoding UTF8
$scriptTag = '<script type="module" src="./src/smart-planner.js"></script>'
if (-not $index.Contains($scriptTag)) {
  if (-not $index.Contains('</body>')) {
    throw 'Could not find </body> in index.html; no automatic markup rewrite was made.'
  }
  $index = $index.Replace('</body>', "$scriptTag`n</body>")
  Set-Content -LiteralPath $indexPath -Value $index -Encoding UTF8
  Write-Host 'Connected smart planner module to index.html.'
} else {
  Write-Host 'Smart planner module is already connected.'
}

$sourceCopy = Join-Path $repoRoot 'source/rahe-talabegi-desktop.html'
if (Test-Path -LiteralPath $sourceCopy -PathType Leaf) {
  Write-Host 'Offline desktop source preserved without modification.'
}

$statusPath = Join-Path $repoRoot 'docs/REQUIREMENTS-STATUS.md'
if (Test-Path -LiteralPath $statusPath -PathType Leaf) {
  $status = Get-Content -LiteralPath $statusPath -Raw -Encoding UTF8
  $oldRow = '| برنامه‌ریز روزانه/فعالیت‌ها | پیاده‌سازی پایه | ویژگی‌های موجود را می‌توان ادامه داد؛ تقویم کامل زمان‌بندی بلوکی و همگام‌سازی ابری نیست. |'
  $newRow = '| برنامه‌ریز روزانه/فعالیت‌ها | پایه + برنامه‌ساز هوشمند محلی در نسخهٔ آنلاین/اندروید | ظرفیت روزانه، اولویت و پیش‌نیازها و تداخل ساعت را بررسی می‌کند؛ تقویم بلوکی سراسری و همگام‌سازی ابری هنوز جداگانه لازم است. |'
  if ($status.Contains($oldRow)) {
    $status = $status.Replace($oldRow, $newRow)
    Set-Content -LiteralPath $statusPath -Value $status -Encoding UTF8
    Write-Host 'Updated planner requirement status.'
  }
}
