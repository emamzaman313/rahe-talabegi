$ErrorActionPreference = 'Stop'
$repoRoot = (Get-Location).Path
$payloadRoot = Join-Path $PSScriptRoot 'files'

if (-not (Test-Path (Join-Path $repoRoot 'package.json'))) {
  throw 'package.json پیدا نشد؛ این بسته باید در ریشهٔ مخزن هم‌قدم اجرا شود.'
}
if (-not (Test-Path (Join-Path $repoRoot 'src/public-chat.js'))) {
  throw 'src/public-chat.js پیدا نشد؛ ساختار مخزن با نسخهٔ مورد انتظار سازگار نیست.'
}

# Copy only this package's files; do not overwrite index.html, workflow files, source/rahdan.html or user data.
Get-ChildItem -LiteralPath $payloadRoot -Recurse -File | ForEach-Object {
  $relative = $_.FullName.Substring($payloadRoot.Length).TrimStart([IO.Path]::DirectorySeparatorChar)
  $destination = Join-Path $repoRoot $relative
  $directory = Split-Path -Parent $destination
  if (-not (Test-Path $directory)) { New-Item -ItemType Directory -Path $directory -Force | Out-Null }
  Copy-Item -LiteralPath $_.FullName -Destination $destination -Force
  Write-Host "Installed: $relative"
}

$chatPath = Join-Path $repoRoot 'src/public-chat.js'
$chat = Get-Content -LiteralPath $chatPath -Raw
$importLine = "import './public-chat-attachments.js';"
if (-not $chat.Contains($importLine)) {
  $anchor = "import './public-chat.css';"
  if (-not $chat.Contains($anchor)) {
    throw "نقطهٔ ادغام import در src/public-chat.js پیدا نشد؛ فایل بدون تغییر باقی ماند."
  }
  $chat = $chat.Replace($anchor, "$anchor`r`n$importLine")
  Set-Content -LiteralPath $chatPath -Value $chat -Encoding utf8
  Write-Host 'Integrated attachment module into src/public-chat.js'
} else {
  Write-Host 'Attachment module import already exists; no duplicate import added.'
}

$statusPath = Join-Path $repoRoot 'docs/REQUIREMENTS-STATUS.md'
if (Test-Path $statusPath) {
  $status = Get-Content -LiteralPath $statusPath -Raw
  $marker = '## افزودهٔ بستهٔ پیوست امن'
  if (-not $status.Contains($marker)) {
    Add-Content -LiteralPath $statusPath -Value @"

$marker

- کد رابط پیوست در `src/public-chat-attachments.js` و اعتبارسنجی در `src/public-chat-attachment-utils.mjs` اضافه شده است.
- migration در `supabase/migrations/20261027150000_public_chat_attachments.sql` ایجاد جدول metadata، bucket خصوصی، سقف ۵۰ MiB و سیاست‌های عضویت اتاق را تعریف می‌کند.
- این قابلیت تا اجرای دستی migration روی پروژهٔ Supabase واقعی و آزمون با دو حساب عضو، «آمادهٔ استقرار» است و نباید «تأییدشده در محیط زنده» نامیده شود.
- فایل‌ها در bucket خصوصی ذخیره می‌شوند؛ لینک دانلود امضاشده یک‌ساعته است. نوع فایل‌های مجاز در migration فهرست شده‌اند.
"@
  }
}
Write-Host 'Package files installed. The existing workflow will run tests/build; database migration is intentionally not auto-applied.'
