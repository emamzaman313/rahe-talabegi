$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$repoRoot = (Get-Location).Path
$filesRoot = Join-Path $PSScriptRoot 'files'

if (-not (Test-Path (Join-Path $repoRoot 'package.json'))) {
  throw "فایل package.json در مسیر جاری پیدا نشد. این بسته باید در ریشهٔ مخزن هم‌قدم اجرا شود: $repoRoot"
}
if (-not (Test-Path (Join-Path $repoRoot 'index.html'))) {
  throw 'index.html پیدا نشد؛ برای محافظت از پروژهٔ نامرتبط، نصب متوقف شد.'
}
if (-not (Test-Path $filesRoot)) { throw "پوشهٔ files پیدا نشد: $filesRoot" }

Write-Host 'هم‌قدم: نصب افزایشی ماژول‌های تکمیلی آغاز شد.' -ForegroundColor Cyan

# Copy only the explicitly packaged paths. Existing offline source files are not touched.
Get-ChildItem -LiteralPath $filesRoot -Force | ForEach-Object {
  $target = Join-Path $repoRoot $_.Name
  if ($_.PSIsContainer) {
    if (-not (Test-Path $target)) { New-Item -ItemType Directory -Path $target -Force | Out-Null }
    Get-ChildItem -LiteralPath $_.FullName -Recurse -File | ForEach-Object {
      $relative = [System.IO.Path]::GetRelativePath($filesRoot, $_.FullName)
      $destination = Join-Path $repoRoot $relative
      $parent = Split-Path -Parent $destination
      if (-not (Test-Path $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
      Copy-Item -LiteralPath $_.FullName -Destination $destination -Force
      Write-Host "  نصب: $relative"
    }
  } else {
    Copy-Item -LiteralPath $_.FullName -Destination $target -Force
    Write-Host "  نصب: $($_.Name)"
  }
}

# Add module entrypoints once; preserve the whole existing HTML body and offline data.
$indexPath = Join-Path $repoRoot 'index.html'
$html = [System.IO.File]::ReadAllText($indexPath, [System.Text.Encoding]::UTF8)
$entrypoints = @(
  '<script type="module" src="./src/smart-planner.js"></script>',
  '<script type="module" src="./src/planner-calendar.js"></script>',
  '<script type="module" src="./src/hamghadam-suite.js"></script>'
)
foreach ($entry in $entrypoints) {
  $moduleName = [regex]::Match($entry, 'src="\./src/([^\"]+)"').Groups[1].Value
  if ($html -notmatch [regex]::Escape($moduleName)) {
    if ($html -match '</body>') { $html = ([regex]::new('</body>', [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)).Replace($html, "$entry`r`n</body>", 1) }
    else { throw 'تگ پایانی body در index.html پیدا نشد؛ ورودی‌های جدید بدون بازنویسی دستی اضافه نشده‌اند.' }
  }
}
[System.IO.File]::WriteAllText($indexPath, $html, [System.Text.UTF8Encoding]::new($false))

# Ensure Vite builds the central admin console as a second/third page without changing workflows.
$vitePath = Join-Path $repoRoot 'vite.config.js'
if (Test-Path $vitePath) {
  $vite = [System.IO.File]::ReadAllText($vitePath, [System.Text.Encoding]::UTF8)
  if ($vite -notmatch "admin:\s*'admin\.html'") {
    if ($vite -match "supportAdmin:\s*'support-admin\.html'") {
      $vite = ([regex]::new("supportAdmin:\s*'support-admin\.html'")).Replace($vite, "supportAdmin: 'support-admin.html',`r`n        admin: 'admin.html'", 1)
    } elseif ($vite -match 'input:\s*\{') {
      $vite = ([regex]::new('input:\s*\{')).Replace($vite, "input: {`r`n        admin: 'admin.html',", 1)
    } else { throw 'ورودی چندصفحه‌ای Vite تشخیص داده نشد؛ پیکربندی به‌صورت کور تغییر نکرد.' }
    [System.IO.File]::WriteAllText($vitePath, $vite, [System.Text.UTF8Encoding]::new($false))
    Write-Host '  به‌روزرسانی: vite.config.js (ورودی admin.html)' -ForegroundColor Yellow
  }
}

# Preserve and append a deployment note rather than replacing existing project documentation.
$notePath = Join-Path $repoRoot 'docs/HAMGHADAM-FINAL-STATUS.md'
$noteDir = Split-Path -Parent $notePath
if (-not (Test-Path $noteDir)) { New-Item -ItemType Directory -Path $noteDir -Force | Out-Null }
$note = @'
# بستهٔ تکمیلی هم‌قدم

این نصب فایل‌های افزایشی را اضافه می‌کند و فایل `source/rahdan.html` و داده‌های آفلاین را بازنویسی نمی‌کند. برای فعال‌شدن کامل قابلیت‌های آنلاین، migration جدید `supabase/migrations/20261027170000_hamghadam_full_suite.sql` باید پس از بازبینی روی پروژهٔ Supabase اجرا شود. تابع `supabase/functions/hamghadam-admin/index.ts` نیز باید با تنظیم امن Secretهای سرور Deploy شود. موفقیت نصب فایل‌ها، به‌تنهایی، اثبات اتصال زنده یا قبولی آزمون انتها‌به‌انتها نیست.
'@
[System.IO.File]::WriteAllText($notePath, $note, [System.Text.UTF8Encoding]::new($false))

Write-Host ''
Write-Host 'نصب فایل‌ها تمام شد. اکنون npm install، npm test و npm run build را اجرا کن؛ در workflow مخزن این مراحل خودکار اجرا می‌شوند.' -ForegroundColor Green
Write-Host 'توجه: SQL migration و تابع Edge به‌صورت خودکار روی سرویس زنده اجرا/منتشر نشده‌اند.' -ForegroundColor Yellow
