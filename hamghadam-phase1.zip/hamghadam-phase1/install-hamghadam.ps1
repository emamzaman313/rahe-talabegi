$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$repoRoot = (Get-Location).Path
$packageRoot = $PSScriptRoot
$payloadRoot = Join-Path $packageRoot 'payload'
foreach ($required in @('package.json','index.html','src/support-chat.js','src/supabase-client.js')) {
  if (-not (Test-Path (Join-Path $repoRoot $required))) {
    throw "فایل لازم پیدا نشد: $required — نصب از ریشهٔ مخزن rahe-talabegi اجرا نشده یا ساختار مخزن تغییر کرده است."
  }
}
if (-not (Test-Path (Join-Path $repoRoot 'src/hamghadam-auth.js'))) {
  Write-Warning 'src/hamghadam-auth.js پیدا نشد؛ اصلاح زمان‌پایان ورود رد می‌شود و در گزارش باقی می‌ماند.'
}

$indexPath = Join-Path $repoRoot 'index.html'
$index = [System.IO.File]::ReadAllText($indexPath, [System.Text.Encoding]::UTF8)
if (-not $index.Contains('</body>')) { throw 'نقطهٔ </body> در index.html پیدا نشد؛ نصب برای جلوگیری از خراب‌کردن برنامه متوقف شد.' }
$supportPath = Join-Path $repoRoot 'src/support-chat.js'
$support = [System.IO.File]::ReadAllText($supportPath, [System.Text.Encoding]::UTF8)
if (-not $support.Contains("import './support-chat.css';") -and -not $support.Contains("import './ai-assistant.js';")) {
  throw 'نقطهٔ اتصال AI در src/support-chat.js پیدا نشد؛ نصب پیش از تغییر فایل‌ها متوقف شد.'
}

$backupStamp = Get-Date -Format 'yyyyMMdd-HHmmss'
if (-not [string]::IsNullOrWhiteSpace($env:RUNNER_TEMP)) {
  # GitHub runner backups stay outside the repository and therefore are not accidentally committed.
  $backupRoot = Join-Path $env:RUNNER_TEMP ("hamghadam-backup-before-phase1/" + $backupStamp)
} else {
  # Local installs keep recoverable copies inside the repository folder.
  $backupRoot = Join-Path $repoRoot (".hamghadam-backup-before-phase1/" + $backupStamp)
}

# Preflight every payload path before any copy operation.
$files = @(Get-ChildItem -LiteralPath $payloadRoot -File -Recurse)
if ($files.Count -lt 6) { throw "بسته ناقص به نظر می‌رسد: فقط $($files.Count) فایل قابل نصب پیدا شد." }
foreach ($file in $files) {
  $relative = $file.FullName.Substring($payloadRoot.Length).TrimStart([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
  if ([IO.Path]::IsPathRooted($relative) -or $relative.Split([char[]]@('/','\')) -contains '..') { throw "مسیر ناامن در بسته: $relative" }
}

# Preserve existing files before updating any of them.
foreach ($file in $files) {
  $relative = $file.FullName.Substring($payloadRoot.Length).TrimStart([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
  $destination = Join-Path $repoRoot $relative
  # Keep the version already in the repository: it may contain newer attachment/realtime integration.
  # The new moderation layer is injected as a separate module and does not need to replace either file.
  $preserveExisting = $false
  if ($relative -in @('src/public-chat.js','src/public-chat.css','src/ai-assistant.js','supabase/functions/hamghadam-ai/index.ts')) {
    $preserveExisting = $true
  }
  if ($relative -match '^supabase/migrations/.*\.sql$' -or $relative -match '^tests/.*\.(js|mjs)$') {
    $preserveExisting = $true
  }
  if ($relative -match '^docs/.*\.(md|txt)$') {
    $preserveExisting = $true
  }
  if ($preserveExisting -and (Test-Path $destination)) {
    Write-Host "Preserving existing project file (non-destructive install): $relative" -ForegroundColor Yellow
    continue
  }
  if (Test-Path $destination) {
    $backup = Join-Path $backupRoot $relative
    New-Item -ItemType Directory -Path (Split-Path -Parent $backup) -Force | Out-Null
    Copy-Item -LiteralPath $destination -Destination $backup -Force
  }
  New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
  Copy-Item -LiteralPath $file.FullName -Destination $destination -Force
}
Write-Host "Payload files installed: $($files.Count). Backup location: $backupRoot" -ForegroundColor Green

# Files changed by anchor-injection or auth patching are not payload files; back them up too.
function Backup-ExistingProjectFile([string]$relativePath) {
  $source = Join-Path $repoRoot $relativePath
  if (-not (Test-Path -LiteralPath $source)) { return }
  $destination = Join-Path $backupRoot $relativePath
  if (Test-Path -LiteralPath $destination) { return }
  New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
  Copy-Item -LiteralPath $source -Destination $destination -Force
}
Backup-ExistingProjectFile 'index.html'
Backup-ExistingProjectFile 'src/support-chat.js'
Backup-ExistingProjectFile 'src/hamghadam-auth.js'
Backup-ExistingProjectFile 'src/public-chat.js'

# Make self-delete match the RLS migration: the row's body must be replaced with the fixed tombstone.
# This is an exact, idempotent patch to the existing public-chat module; a backup is created above first.
$publicChatPath = Join-Path $repoRoot 'src/public-chat.js'
$publicChat = [System.IO.File]::ReadAllText($publicChatPath, [System.Text.Encoding]::UTF8)
$oldDelete = ".update({deleted_at:new Date().toISOString()})"
$newDelete = ".update({body:'این پیام حذف شد.',deleted_at:new Date().toISOString()})"
if ($publicChat.Contains($oldDelete)) {
  $publicChat = $publicChat.Replace($oldDelete, $newDelete)
  [System.IO.File]::WriteAllText($publicChatPath, $publicChat, [System.Text.UTF8Encoding]::new($false))
} elseif (-not $publicChat.Contains($newDelete)) {
  throw 'وصلهٔ حذف نرم چت پیدا نشد؛ فایل src/public-chat.js تغییر کرده است. برای جلوگیری از نصب نیمه‌کاره، workflow باید متوقف شود.'
}

# Connect the AI module to the existing support module without replacing its logic.
$support = [System.IO.File]::ReadAllText($supportPath, [System.Text.Encoding]::UTF8)
if (-not $support.Contains("import './ai-assistant.js';")) {
  $anchor = "import './support-chat.css';"
  if (-not $support.Contains($anchor)) { throw 'فایل‌ها کپی شدند، اما نقطهٔ اتصال AI تغییر کرده است؛ workflow باید شکست بخورد و commit انجام نشود.' }
  $support = $support.Replace($anchor, "$anchor`nimport './ai-assistant.js';")
  [System.IO.File]::WriteAllText($supportPath, $support, [System.Text.UTF8Encoding]::new($false))
}

# Connect public chat as a module only once.
$index = [System.IO.File]::ReadAllText($indexPath, [System.Text.Encoding]::UTF8)
if (-not $index.Contains('public-chat.js')) {
  $tag = '<script type="module" src="./src/public-chat.js"></script>'
  $pos = $index.LastIndexOf('</body>', [StringComparison]::OrdinalIgnoreCase)
  if ($pos -lt 0) { throw 'نقطهٔ اتصال گفت‌وگوی عمومی پیدا نشد؛ workflow باید شکست بخورد.' }
  $index = $index.Insert($pos, "$tag`n")
  [System.IO.File]::WriteAllText($indexPath, $index, [System.Text.UTF8Encoding]::new($false))
}

# Add the moderation/report UI as a separate module; never replace the current chat implementation.
$index = [System.IO.File]::ReadAllText($indexPath, [System.Text.Encoding]::UTF8)
if (-not $index.Contains('public-chat-moderation.js')) {
  $tag = '<script type="module" src="./src/public-chat-moderation.js"></script>'
  $pos = $index.LastIndexOf('</body>', [StringComparison]::OrdinalIgnoreCase)
  if ($pos -lt 0) { throw 'نقطهٔ اتصال ماژول نظارت چت پیدا نشد؛ workflow باید شکست بخورد.' }
  $index = $index.Insert($pos, "$tag`n")
  [System.IO.File]::WriteAllText($indexPath, $index, [System.Text.UTF8Encoding]::new($false))
}

# Apply bounded auth waits if the current source still matches the known safe anchor.
$authPatch = Join-Path $repoRoot 'scripts/apply-auth-timeout-patch.mjs'
$authFile = Join-Path $repoRoot 'src/hamghadam-auth.js'
if ((Test-Path $authPatch) -and (Test-Path $authFile)) {
  & node $authPatch $authFile
  if ($LASTEXITCODE -ne 0) { throw 'وصلهٔ زمان‌پایان ورود ناموفق بود؛ workflow باید شکست بخورد.' }
}

Write-Host ''
Write-Host 'نصب افزونه انجام شد؛ چت/پیوند پیوست موجود حفظ شد. migrationهای SQL هنوز روی Supabase اجرا نشده‌اند؛ گزارش‌ها، اقدامات نظارتی و سقف گروه پس از backup و اجرای چهار migration جدید فعال می‌شوند.' -ForegroundColor Cyan
