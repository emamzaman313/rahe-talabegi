$ErrorActionPreference = 'Stop'
$repoRoot = (Get-Location).Path
$python = Get-Command python3 -ErrorAction SilentlyContinue
if (-not $python) { throw 'Python 3 is required to apply the checked patch.' }
& python3 (Join-Path $PSScriptRoot 'apply_patch.py') $repoRoot (Join-Path $PSScriptRoot 'patch')
if ($LASTEXITCODE -ne 0) { throw "Patch application failed with exit code $LASTEXITCODE" }
Write-Host 'Hamghadam Phase 1 patch applied. Tests and build will run in the workflow.'
