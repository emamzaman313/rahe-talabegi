$ErrorActionPreference = 'Stop'

function Write-Utf8NoBom([string]$Path, [string]$Value) {
  [System.IO.File]::WriteAllText($Path, $Value, [System.Text.UTF8Encoding]::new($false))
}

function Replace-Once([string]$Text, [string]$Old, [string]$New, [string]$Label) {
  $index = $Text.IndexOf($Old, [StringComparison]::Ordinal)
  if ($index -lt 0) { throw "نشانهٔ لازم پیدا نشد: $Label. پیش‌آزمایش ناموفق بود؛ فایل‌های اصلی دست‌نخورده‌اند." }
  if ($Text.IndexOf($Old, $index + $Old.Length, [StringComparison]::Ordinal) -ge 0) {
    Write-Host "هشدار: نشانهٔ $Label چند بار وجود دارد؛ فقط نخستین مورد تغییر می‌کند." -ForegroundColor Yellow
  }
  return $Text.Substring(0, $index) + $New + $Text.Substring($index + $Old.Length)
}

$root = (Get-Location).Path
$required = @('index.html','package.json','capacitor.config.json','support-admin.html','src/support-chat.js')
foreach ($path in $required) {
  if (-not (Test-Path (Join-Path $root $path))) { throw "این پوشه ریشهٔ مخزن هم‌قدم/راه‌طلبگی نیست؛ فایل پیدا نشد: $path" }
}

$indexPath = Join-Path $root 'index.html'
$chatPath = Join-Path $root 'src/support-chat.js'
$adminPath = Join-Path $root 'support-admin.html'
$configPath = Join-Path $root 'capacitor.config.json'
$html = Get-Content -Raw -Encoding UTF8 $indexPath
$chat = (Get-Content -Raw -Encoding UTF8 $chatPath).Replace("`r`n", "`n")
$admin = Get-Content -Raw -Encoding UTF8 $adminPath
$config = Get-Content -Raw -Encoding UTF8 $configPath

if ($html.Contains('src/hamghadam-auth.js') -or $html.Contains('hg-auth-checking')) {
  throw 'به‌نظر می‌رسد فاز اول قبلاً در index.html نصب شده است؛ اسکریپت را دوباره اجرا نکن. ابتدا پوشهٔ پشتیبان قبلی را بررسی کن.'
}

# Preflight: calculate every transformed file in memory before writing any changed file.
$html = Replace-Once $html '<head>' '<head><script>document.documentElement.classList.add("hg-auth-checking");</script>' 'شروع قفل احراز هویت'
$html = Replace-Once $html '</head>' '<style>html.hg-auth-checking body>.app{visibility:hidden!important}html.hg-auth-checking #toast{visibility:hidden!important}</style></head>' 'مخفی‌کردن محتوای داخلی پیش از بررسی نشست'
$html = Replace-Once $html '<title>راهِ طلبگی | برنامه‌ریزی، مطالعه و خودسازی</title>' '<title>هم‌قدم | مسیر یادگیری، مطالعه و همفکری</title>' 'عنوان برنامه'
$html = Replace-Once $html '<h1>راهِ طلبگی</h1>' '<h1>هم‌قدم</h1>' 'نام برند در سربرگ'
$html = $html.Replace('برنامه‌ریزی، مطالعه، خودسازی و سواد رسانه‌ای','همراه مسیر علم، مطالعه و رشد')
$html = $html.Replace('نسخهٔ آفلاین • متن‌های علمیِ نیازمند بررسی منبع، با برچسب مشخص شده‌اند • این ابزار جایگزین استاد، مرجع تقلید یا متخصص سلامت نیست.','هم‌قدم • مرحلهٔ پایهٔ احراز هویت و پروفایل سروری • بخش‌هایی از داده‌های قدیمی هنوز روی همین دستگاه ذخیره می‌شوند.')
# Keep the legacy storage key and filenames intact; only update visible product branding.
$html = $html.Replace('راهِ طلبگی','هم‌قدم').Replace('راه طلبگی','هم‌قدم').Replace('راه‌طلبگی','هم‌قدم')
$html = Replace-Once $html 'let state=loadState();' 'let state=loadState(); window.__RAHE_STATE__=state;' 'دسترس‌پذیری برای ادغام پروفایل سرور'
$closeBody = $html.LastIndexOf('</body>', [StringComparison]::Ordinal)
if ($closeBody -lt 0) { throw 'تگ پایانی body پیدا نشد؛ index.html را دستی بررسی کن.' }
$html = $html.Insert($closeBody, '<script type="module" src="./src/bidayat-al-nahw-ui.js"></script><script type="module" src="./src/hamghadam-auth.js"></script>')

$chat = Replace-Once $chat "import { createClient } from '@supabase/supabase-js';`nimport './support-chat.css';" "import './support-chat.css';`nimport { supabase as sharedSupabase, isSupabaseConfigured } from './supabase-client.js';" 'استفاده از کلاینت مشترک Supabase'
$chat = Replace-Once $chat "import { escapeHtml, formatTimestamp, isSupportAgent, isValidSupabaseConfig, normalizeMessage, statusLabel } from './support-utils.mjs';" "import { escapeHtml, formatTimestamp, isSupportAgent, normalizeMessage, statusLabel } from './support-utils.mjs';" 'حذف اعتبارسنجی پیکربندی تکراری'
$oldConfigPattern = @'
const PROJECT_URL = import\.meta\.env\.VITE_SUPABASE_URL \|\| '';
const PUBLISHABLE_KEY = import\.meta\.env\.VITE_SUPABASE_PUBLISHABLE_KEY \|\| '';
const CONFIGURED = isValidSupabaseConfig\(PROJECT_URL, PUBLISHABLE_KEY\);
const db = CONFIGURED \? createClient\(PROJECT_URL, PUBLISHABLE_KEY, \{
  auth: \{ persistSession: true, autoRefreshToken: true, detectSessionInUrl: true \}
\}\) : null;
'@
$newConfig = "const CONFIGURED = isSupabaseConfigured;`nconst db = sharedSupabase;"
$chat = [regex]::Replace($chat, $oldConfigPattern, $newConfig, [System.Text.RegularExpressions.RegexOptions]::None, [TimeSpan]::FromSeconds(2))
if ($chat -match 'const PROJECT_URL = import\.meta\.env') { throw 'بلوک کلاینت تکراری پشتیبانی حذف نشد؛ پیش‌آزمایش ناموفق است و فایل‌های اصلی دست‌نخورده‌اند.' }

$admin = $admin.Replace('صندوق پشتیبانی | راه طلبگی','صندوق پشتیبانی | هم‌قدم').Replace('صندوق پشتیبانی راهِ طلبگی','صندوق پشتیبانی هم‌قدم').Replace('راهِ طلبگی','هم‌قدم').Replace('راه طلبگی','هم‌قدم')
$config = Replace-Once $config '"appName": "راه طلبگی"' '"appName": "هم‌قدم"' 'نام برنامهٔ اندروید'

$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$incoming = @('src/supabase-client.js','src/hamghadam-auth-utils.mjs','src/hamghadam-auth.js','src/hamghadam-auth.css','src/bidayat-al-nahw-catalog.mjs','src/bidayat-al-nahw-ui.js','src/bidayat-al-nahw-ui.css','docs/BIDAYAT-AL-NAHW-REVIEW.md','supabase/migrations/20261024112748_hamghadam_profiles.sql','supabase/migrations/20261024113242_hamghadam_profile_column_grants.sql','supabase/migrations/20261024114000_hamghadam_profile_updated_at.sql','tests/hamghadam-auth.test.mjs','tests/bidayat-catalog.test.mjs')
foreach ($path in $incoming) {
  if (-not (Test-Path (Join-Path $packageRoot $path))) { throw "فایل بسته ناقص است: $path. فایل‌های اصلی هنوز دست‌نخورده‌اند." }
}

# Backup every pre-existing file that will be overwritten, including any prior partial installation.
$backupPaths = @('index.html','capacitor.config.json','support-admin.html','src/support-chat.js')
foreach ($path in $incoming) { if (Test-Path (Join-Path $root $path)) { $backupPaths += $path } }
$backupPaths = $backupPaths | Select-Object -Unique
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backup = Join-Path $root ".hamghadam-backup-$stamp"
New-Item -ItemType Directory -Path $backup | Out-Null
foreach ($path in $backupPaths) {
  $dest = Join-Path $backup $path
  New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
  Copy-Item (Join-Path $root $path) $dest
}
Write-Host "پشتیبان فایل‌های قبلی ساخته شد: $backup" -ForegroundColor Green

try {
  foreach ($path in $incoming) {
    $source = Join-Path $packageRoot $path
    $dest = Join-Path $root $path
    New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
    Copy-Item $source $dest -Force
  }
  Write-Utf8NoBom $indexPath $html
  Write-Utf8NoBom $chatPath $chat
  Write-Utf8NoBom $adminPath $admin
  Write-Utf8NoBom $configPath $config
} catch {
  Write-Host "اعمال تغییرات کامل نشد. نسخه‌های قبلی در $backup محفوظ‌اند." -ForegroundColor Red
  throw
}

Write-Host ''
Write-Host 'فاز اول هم‌قدم نصب شد.' -ForegroundColor Green
Write-Host 'در همین پوشه اجرا کن: npm test و سپس npm run build' -ForegroundColor Cyan
Write-Host 'پس از موفقیت build، تغییرها را به main در GitHub بفرست تا Pages و APK دوباره ساخته شوند.' -ForegroundColor Cyan
Write-Host 'داده‌های برنامه‌ریز قدیمی در این مرحله به‌طور خودکار به سرور منتقل نمی‌شوند.' -ForegroundColor Yellow
