import './hamghadam-auth.css';
import { supabase, isSupabaseConfigured } from './supabase-client.js';
import {
  greetingName,
  normalizeDisplayName,
  normalizeFreeMinutes,
  normalizeStage,
  normalizeStudyStyle,
  profilePayload,
  roleLabel,
  trustedRole,
} from './hamghadam-auth-utils.mjs';

const PROFILE_COLUMNS = 'id,display_name,stage,free_minutes,study_style,created_at,updated_at';
const GATE_ID = 'hg-auth-gate';
let user = null;
let profile = null;
let mode = 'login';
let busy = false;
let notice = '';
let noticeType = 'info';
let lastHydratedUserId = null;

const $ = (selector, root = document) => root.querySelector(selector);
const escape = (value) => String(value ?? '').replace(/[&<>"']/g, (ch) => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' })[ch]);

function getLegacyProfile() {
  try {
    const state = window.__RAHE_STATE__ || JSON.parse(localStorage.getItem('rahe-talabegi-v1') || 'null');
    return state?.profile || {};
  } catch { return {}; }
}

function applyProfileToLegacyState(row) {
  if (!row) return;
  const target = window.__RAHE_STATE__;
  if (target?.profile) {
    Object.assign(target.profile, {
      name: row.display_name || '',
      stage: row.stage || 'پایه یک',
      freeMinutes: row.free_minutes ?? 60,
      studyStyle: row.study_style || 'ترکیبی',
    });
    try { localStorage.setItem('rahe-talabegi-v1', JSON.stringify(target)); } catch { /* cache is optional */ }
    if (typeof window.render === 'function') {
      try { window.render(); } catch { /* the current view can still operate */ }
    }
  }
}

function renderMountain() {
  return `<svg class="hg-mountain" viewBox="0 0 620 190" role="img" aria-label="نقشهٔ نمادین مسیر رشد و یادگیری">
    <defs><linearGradient id="hgPeakA" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#83e0cb" stop-opacity=".55"/><stop offset="1" stop-color="#1f786f" stop-opacity=".13"/></linearGradient><linearGradient id="hgPeakB" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#efd28d" stop-opacity=".5"/><stop offset="1" stop-color="#a6d6c9" stop-opacity=".05"/></linearGradient></defs>
    <path d="M0 162 90 92 135 124 238 25 310 111 365 64 469 132 523 100 620 153V190H0Z" fill="url(#hgPeakA)"/>
    <path d="m194 66 44-41 42 50-35-14-17 13-15-16-19 8Z" fill="#c8f2e4" opacity=".8"/><path d="M0 176 116 126 178 145 275 92 359 155 447 119 620 178V190H0Z" fill="#0a222b" opacity=".72"/>
    <path d="M44 157 Q115 143 151 112 T239 82 T316 116 T401 105 T496 133" fill="none" stroke="#9be6d4" stroke-width="2" stroke-linecap="round" stroke-dasharray="4 7" opacity=".85"/>
    <circle cx="151" cy="112" r="5" fill="#f2cb7d" stroke="#f9e6b7" stroke-width="3"/><circle cx="316" cy="116" r="5" fill="#66d3bb" stroke="#c7f5e7" stroke-width="3"/><circle cx="496" cy="133" r="5" fill="#f2cb7d" stroke="#f9e6b7" stroke-width="3"/><path d="m239 78 10-16 10 16Z" fill="#f2cb7d"/>
  </svg>`;
}

function renderGate() {
  const titles = {
    login: ['خوش برگشتی', 'برای ادامهٔ مسیرت وارد حساب هم‌قدم شو.', 'ورود به هم‌قدم'],
    signup: ['از همین قدم شروع کن', 'یک حساب بساز تا مسیرت بین دستگاه‌ها ادامه پیدا کند.', 'ساخت حساب'],
    reset: ['بازیابی رمز عبور', 'نشانی ایمیلت را بنویس تا راهنمای بازیابی ارسال شود.', 'ارسال راهنمای بازیابی'],
    update: ['رمز تازه انتخاب کن', 'رمز عبور جدیدی برای حساب خودت ثبت کن.', 'ثبت رمز تازه'],
  };
  const [title, subtitle, submit] = titles[mode] || titles.login;
  const showPassword = mode !== 'reset';
  const passwordLabel = mode === 'update' ? 'رمز عبور تازه' : 'رمز عبور';
  const form = isSupabaseConfigured ? `<form class="hg-form" id="hg-auth-form" novalidate>
    ${mode === 'signup' ? `<div class="hg-field"><label for="hg-name">نام نمایشی (اختیاری)</label><input id="hg-name" name="display_name" type="text" maxlength="60" autocomplete="nickname" placeholder="مثلاً علی"></div>` : ''}
    ${mode !== 'update' ? `<div class="hg-field"><label for="hg-email">ایمیل</label><input id="hg-email" name="email" type="email" autocomplete="email" maxlength="254" required placeholder="you@example.com" dir="ltr"></div>` : ''}
    ${showPassword ? `<div class="hg-field"><label for="hg-password">${passwordLabel}</label><input id="hg-password" name="password" type="password" autocomplete="${mode === 'update' ? 'new-password' : mode === 'signup' ? 'new-password' : 'current-password'}" minlength="8" maxlength="128" required placeholder="حداقل ۸ نویسه" dir="ltr"></div>` : ''}
    ${notice ? `<div class="hg-alert ${escape(noticeType)}" role="status" aria-live="polite">${escape(notice)}</div>` : ''}
    <button class="hg-submit" type="submit" ${busy ? 'disabled' : ''}><span>${busy ? 'در حال انجام…' : submit}</span><span aria-hidden="true">↙</span></button>
    <div class="hg-form-row">${mode !== 'login' && mode !== 'update' ? `<button class="hg-link" type="button" data-hg-mode="login">بازگشت به ورود</button>` : ''}${mode === 'login' ? `<button class="hg-link" type="button" data-hg-mode="reset">رمز را فراموش کرده‌ام</button><button class="hg-link" type="button" data-hg-mode="signup">حساب ندارم؛ ثبت‌نام</button>` : mode === 'signup' ? `<button class="hg-link" type="button" data-hg-mode="login">حساب دارم؛ ورود</button>` : mode === 'update' ? `<button class="hg-link" type="button" data-hg-mode="login">لغو</button>` : ''}</div>
  </form>` : `<div class="hg-alert warn" role="status">اتصال امن هنوز در تنظیمات ساخت وب/اندروید تعریف نشده است. تا زمان تنظیم نشانی پروژه و کلید عمومی Supabase، ورود فعال نمی‌شود.</div><ol class="hg-setup-list"><li>نشانی پروژه را با متغیر <code>VITE_SUPABASE_URL</code> تنظیم کن.</li><li>کلید عمومی را با متغیر <code>VITE_SUPABASE_PUBLISHABLE_KEY</code> تنظیم کن.</li><li>برنامه را دوباره build کن. کلید secret یا <code>service_role</code> را هرگز داخل اپ قرار نده.</li></ol>`;

  return `<div class="hg-shell"><section class="hg-story" aria-label="معرفی هم‌قدم">
    <div class="hg-brand"><div class="hg-brandmark" aria-hidden="true">هـ</div><div><div class="hg-brandname">هم‌قدم</div><div class="hg-brandtag">همراه مسیر علم، مطالعه و رشد</div></div></div>
    <span class="hg-eyebrow">یک مسیر روشن، قدم‌به‌قدم</span>
    <h1>راهی برای <span>یادگرفتنِ عمیق‌تر</span> و ادامه‌دادن.</h1>
    <p>برنامه‌ریزی، کتاب‌خوانی، تمرین نحو و صرف و همفکری در یک فضای آرام و منظم؛ با حساب شخصی که از مسیر سرور مدیریت می‌شود.</p>
    ${renderMountain()}
    <div class="hg-benefits"><div class="hg-benefit"><i>◷</i><b>برنامه و هدف</b><span>قدم‌های کوچک و برنامهٔ قابل تنظیم</span></div><div class="hg-benefit"><i>ق</i><b>نحو و صرف</b><span>تمرین و مرور علمی با توجه به کتاب درسی</span></div><div class="hg-benefit"><i>▤</i><b>کتاب و مطالعه</b><span>ادامهٔ مسیر یادگیری به‌تدریج تکمیل می‌شود</span></div><div class="hg-benefit"><i>✦</i><b>همفکری و پشتیبانی</b><span>ارتباط با حساب و نشست معتبر</span></div></div>
  </section><section class="hg-auth-card" aria-labelledby="hg-auth-title">
    <div class="hg-card-top"><div><h2 id="hg-auth-title">${title}</h2><p>${subtitle}</p></div><div class="hg-card-emblem" aria-hidden="true">✧</div></div>
    ${form}
    <div class="hg-card-bottom">با ورود، از همان حساب برای پیام‌های پشتیبانی استفاده می‌کنی. تأیید ایمیل و بازیابی رمز مطابق تنظیمات واقعی سرویس انجام می‌شود؛ هیچ تأیید ساختگی یا ورود مهمان وجود ندارد.</div>
    <div class="hg-privacy"><span>◈</span><div>پروفایل پایه به سرور همگام می‌شود. داده‌های قدیمی برنامه‌ریز که هنوز منتقل نشده‌اند، روی همین دستگاه باقی می‌مانند؛ این مرحله آن‌ها را خودکار آپلود نمی‌کند.</div></div>
  </section></div>`;
}

function setGateOpen(open) {
  const root = document.getElementById(GATE_ID);
  if (root) root.hidden = !open;
  const app = document.querySelector('body > .app');
  if (app) {
    app.inert = open;
    app.setAttribute('aria-hidden', open ? 'true' : 'false');
  }
  if (open) {
    document.documentElement.classList.add('hg-auth-checking');
    document.body.classList.add('hg-auth-locked');
  } else {
    document.documentElement.classList.remove('hg-auth-checking');
    document.body.classList.remove('hg-auth-locked');
  }
}

function ensureAccountBox() {
  const actions = $('.topbar .topactions');
  if (!actions) return;
  let box = $('#hg-account-box');
  if (!box) {
    box = document.createElement('div');
    box.id = 'hg-account-box';
    box.className = 'hg-account';
    actions.prepend(box);
  }
  const role = trustedRole(user);
  const name = greetingName(profile, user);
  box.innerHTML = `<span class="hg-account-chip" title="حساب متصل به سرور"><span class="hg-account-dot"></span><span class="hg-account-name">${escape(name)}</span><span class="hg-role">${escape(roleLabel(role))}</span></span><button type="button" class="hg-account-btn" data-hg-action="profile">پروفایل</button>${role === 'support' ? '<a class="hg-account-btn" href="./support-admin.html" rel="noopener">صندوق پشتیبانی</a>' : ''}<button type="button" class="hg-account-btn danger" data-hg-action="logout">خروج</button>`;
}

async function loadOrCreateProfile(authUser) {
  const fallback = getLegacyProfile();
  const seed = {
    id: authUser.id,
    display_name: normalizeDisplayName(authUser.user_metadata?.display_name, fallback.name || String(authUser.email || '').split('@')[0]),
    stage: normalizeStage(fallback.stage, 'پایه یک'),
    free_minutes: normalizeFreeMinutes(fallback.freeMinutes, 60),
    study_style: normalizeStudyStyle(fallback.studyStyle, 'ترکیبی'),
  };
  let result = await supabase.from('profiles').select(PROFILE_COLUMNS).eq('id', authUser.id).maybeSingle();
  if (result.error) throw result.error;
  if (result.data) return result.data;
  result = await supabase.from('profiles').insert(seed).select(PROFILE_COLUMNS).single();
  if (result.error) {
    // A concurrent sign-in may have created the row; reread it before failing.
    const retry = await supabase.from('profiles').select(PROFILE_COLUMNS).eq('id', authUser.id).maybeSingle();
    if (!retry.error && retry.data) return retry.data;
    throw result.error;
  }
  return result.data;
}

async function acceptSession(session) {
  if (!session?.user) {
    user = null;
    profile = null;
    lastHydratedUserId = null;
    mode = 'login';
    setGateOpen(true);
    renderGateIntoRoot();
    return;
  }
  const authUser = session.user;
  const changed = lastHydratedUserId !== authUser.id;
  user = authUser;
  setGateOpen(false);
  ensureAccountBox();
  if (changed) {
    lastHydratedUserId = authUser.id;
    try {
      profile = await loadOrCreateProfile(authUser);
      applyProfileToLegacyState(profile);
      ensureAccountBox();
    } catch (error) {
      notice = `وارد حساب شدی، اما پروفایل سروری بارگذاری نشد: ${error?.message || 'خطای اتصال'}`;
      noticeType = 'warn';
      showLegacyToast(notice);
    }
  }
}

function showLegacyToast(message) {
  const toast = $('#toast');
  if (toast) {
    toast.textContent = message;
    toast.classList.remove('hide');
    clearTimeout(showLegacyToast.timer);
    showLegacyToast.timer = setTimeout(() => toast.classList.add('hide'), 5000);
  }
}

function renderGateIntoRoot() {
  const root = document.getElementById(GATE_ID);
  if (!root) return;
  root.innerHTML = renderGate();
  root.hidden = false;
  const email = $('#hg-email', root);
  if (email && user?.email) email.value = user.email;
}

function setMode(next) {
  mode = ['login', 'signup', 'reset', 'update'].includes(next) ? next : 'login';
  notice = '';
  noticeType = 'info';
  busy = false;
  renderGateIntoRoot();
  const target = $('#hg-email') || $('#hg-password');
  target?.focus({ preventScroll: true });
}

async function handleSubmit(form) {
  if (!supabase || busy) return;
  const data = new FormData(form);
  const email = String(data.get('email') || '').trim().toLowerCase();
  const password = String(data.get('password') || '');
  const name = normalizeDisplayName(data.get('display_name'), '');
  if (mode !== 'update' && mode !== 'reset' && !email) return setNotice('ایمیل را وارد کن.', 'error');
  if ((mode === 'login' || mode === 'signup' || mode === 'update') && password.length < 8) return setNotice('رمز عبور باید دست‌کم ۸ نویسه داشته باشد.', 'error');
  busy = true;
  notice = '';
  renderGateIntoRoot();
  try {
    if (mode === 'signup') {
      const { data: response, error } = await supabase.auth.signUp({ email, password, options: { data: { display_name: name } } });
      if (error) throw error;
      if (response.session) await acceptSession(response.session);
      else setNotice('ثبت‌نام انجام شد. اگر تأیید ایمیل فعال است، ایمیل را تأیید کن و سپس وارد شو.', 'info');
    } else if (mode === 'login') {
      const { data: response, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      await acceptSession(response.session);
    } else if (mode === 'reset') {
      const redirectTo = `${location.origin}${location.pathname}`;
      const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo });
      if (error) throw error;
      setNotice('اگر این ایمیل به حسابی متصل باشد، راهنمای بازیابی ارسال می‌شود.', 'info');
    } else if (mode === 'update') {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;
      setMode('login');
      setNotice('رمز عبور تغییر کرد. اکنون می‌توانی وارد شوی.', 'info');
    }
  } catch (error) {
    const message = String(error?.message || 'عملیات ناموفق بود.');
    const friendly = /invalid login credentials/i.test(message) ? 'ایمیل یا رمز عبور درست نیست.'
      : /email not confirmed/i.test(message) ? 'ایمیل هنوز تأیید نشده است؛ صندوق ایمیلت را بررسی کن.'
      : /user already registered/i.test(message) ? 'این ایمیل قبلاً ثبت شده است؛ وارد حساب شو.'
      : `عملیات انجام نشد: ${message}`;
    setNotice(friendly, 'error');
  } finally {
    busy = false;
    if (document.getElementById(GATE_ID) && !user) renderGateIntoRoot();
  }
}

function setNotice(message, type = 'info') {
  notice = message;
  noticeType = type;
  renderGateIntoRoot();
}

async function editProfile() {
  if (!user || !supabase || busy) return;
  const currentName = profile?.display_name || '';
  const enteredName = window.prompt('نام نمایشی هم‌قدم:', currentName);
  if (enteredName === null) return;
  const display_name = normalizeDisplayName(enteredName, '');
  if (display_name.length > 60) return showLegacyToast('نام نمایشی حداکثر ۶۰ نویسه است.');
  const stage = normalizeStage(window.prompt('پایه یا مرحلهٔ تحصیلی:', profile?.stage || 'پایه یک'), profile?.stage || 'پایه یک');
  if (stage.length > 60) return showLegacyToast('عنوان مرحله حداکثر ۶۰ نویسه است.');
  busy = true;
  try {
    const { data, error } = await supabase.from('profiles').update({ display_name, stage }).eq('id', user.id).select(PROFILE_COLUMNS).single();
    if (error) throw error;
    profile = data;
    applyProfileToLegacyState(profile);
    ensureAccountBox();
    showLegacyToast('پروفایل روی سرور ذخیره شد.');
  } catch (error) {
    showLegacyToast(`پروفایل ذخیره نشد: ${error?.message || 'خطای سرور'}`);
  } finally { busy = false; }
}

async function logout() {
  if (!supabase || busy) return;
  busy = true;
  try {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  } catch (error) {
    busy = false;
    showLegacyToast(`خروج انجام نشد: ${error?.message || 'خطا'}`);
  }
}

async function syncPreferences(payload) {
  if (!supabase || !user) return;
  const update = {
    display_name: normalizeDisplayName(payload.display_name, ''),
    stage: normalizeStage(payload.stage, 'پایه یک'),
    free_minutes: normalizeFreeMinutes(payload.free_minutes, 60),
    study_style: normalizeStudyStyle(payload.study_style, 'ترکیبی'),
  };
  try {
    const { data, error } = await supabase.from('profiles').update(update).eq('id', user.id).select(PROFILE_COLUMNS).single();
    if (error) throw error;
    profile = data;
    applyProfileToLegacyState(profile);
    ensureAccountBox();
  } catch (error) {
    showLegacyToast(`تنظیمات محلی ذخیره شد، اما همگام‌سازی سرور ناموفق بود: ${error?.message || 'خطای شبکه'}`);
  }
}

function mount() {
  let root = document.getElementById(GATE_ID);
  if (!root) {
    root = document.createElement('div');
    root.id = GATE_ID;
    root.hidden = true;
    document.body.append(root);
  }
  if (!isSupabaseConfigured || !supabase) {
    setGateOpen(true);
    renderGateIntoRoot();
    return;
  }

  document.addEventListener('click', (event) => {
    const modeButton = event.target.closest('[data-hg-mode]');
    if (modeButton && root.contains(modeButton)) { setMode(modeButton.dataset.hgMode); return; }
    const action = event.target.closest('[data-hg-action]')?.dataset.hgAction;
    if (action === 'profile') void editProfile();
    else if (action === 'logout') void logout();
  });
  document.addEventListener('submit', (event) => {
    if (event.target?.id === 'hg-auth-form') { event.preventDefault(); void handleSubmit(event.target); }
  });

  // Capture the values before the legacy settings handler rerenders its form.
  document.addEventListener('submit', (event) => {
    const form = event.target;
    if (form instanceof HTMLFormElement && form.dataset.form === 'preferences' && user) {
      const payload = profilePayload(new FormData(form), profile || {});
      setTimeout(() => void syncPreferences(payload), 0);
    }
  }, true);

  supabase.auth.onAuthStateChange((event, session) => {
    if (event === 'PASSWORD_RECOVERY') {
      mode = 'update'; notice = 'برای ادامه، رمز عبور تازه را ثبت کن.'; noticeType = 'info';
      setGateOpen(true); renderGateIntoRoot(); return;
    }
    // Do not await Supabase queries inside the auth callback; that can stall auth's internal lock.
    setTimeout(() => void acceptSession(session), 0);
  });

  setGateOpen(true);
  renderGateIntoRoot();
  void supabase.auth.getSession().then(({ data, error }) => {
    if (error) setNotice(`خواندن نشست انجام نشد: ${error.message}`, 'error');
    void acceptSession(data?.session || null);
  }).catch((error) => setNotice(`اتصال ورود ناموفق بود: ${error?.message || 'خطای شبکه'}`, 'error'));
}

mount();
