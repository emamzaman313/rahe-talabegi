import test from "node:test";
import assert from "node:assert/strict";
import { findMoveConflicts, getCalendarDates, moveTaskDate } from "../src/planner-calendar-core.mjs";

test("week calendar starts Saturday and contains seven consecutive dates", () => {
  const days = getCalendarDates("2026-10-27", "week");
  assert.equal(days.length, 7);
  assert.equal(new Date(days[0].date + "T12:00:00").getDay(), 6);
  assert.equal(days[0].date, "2026-10-24");
  assert.equal(days[6].date, "2026-10-30");
});

test("month view provides six Saturday-first weeks and marks adjacent-month dates", () => {
  const days = getCalendarDates("2026-10-27", "month");
  assert.equal(days.length, 42);
  assert.equal(days[0].date, "2026-09-26");
  assert.equal(days.filter((day) => day.inAnchorMonth).length, 31);
});

test("move conflict detects partial overlap but permits adjacent appointments", () => {
  const tasks = [
    { id: "move", date: "2026-10-27", start: "10:00", end: "10:30", status: "pending" },
    { id: "overlap", date: "2026-10-28", start: "10:20", end: "10:50", status: "pending" },
    { id: "adjacent", date: "2026-10-28", start: "10:30", end: "11:00", status: "pending" },
  ];
  const result = findMoveConflicts(tasks, "move", "2026-10-28");
  assert.deepEqual(result.conflicts.map((task) => task.id), ["overlap"]);
});

test("completed and sample tasks do not block moving a real task", () => {
  const tasks = [
    { id: "move", date: "2026-10-27", start: "10:00", end: "10:30", status: "pending" },
    { id: "done", date: "2026-10-28", start: "10:00", end: "10:30", status: "done" },
    { id: "sample", date: "2026-10-28", start: "10:00", end: "10:30", sample: true, status: "pending" },
  ];
  const result = moveTaskDate(tasks, "move", "2026-10-28");
  assert.equal(result.moved, true);
  assert.equal(tasks[0].date, "2026-10-28");
});

test("does not move a task when an overlap exists and rejects sample activities", () => {
  const tasks = [
    { id: "move", date: "2026-10-27", start: "10:00", end: "10:30", status: "pending" },
    { id: "block", date: "2026-10-28", start: "09:45", end: "10:15", status: "pending" },
    { id: "sample", date: "2026-10-27", sample: true, start: "12:00", end: "12:30" },
  ];
  const result = moveTaskDate(tasks, "move", "2026-10-28");
  assert.equal(result.moved, false);
  assert.equal(tasks[0].date, "2026-10-27");
  assert.throws(() => moveTaskDate(tasks, "sample", "2026-10-29"), /فعالیت نمونه/);
});
