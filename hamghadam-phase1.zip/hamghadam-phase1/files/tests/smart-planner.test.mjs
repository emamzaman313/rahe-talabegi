import test from "node:test";
import assert from "node:assert/strict";
import {
  makeStudyPlan,
  orderTopicsByPriorityAndPrerequisites,
  parseStudyTopics,
} from "../src/smart-planner-core.mjs";

test("parses topics, priorities, duration and comma-separated prerequisites", () => {
  const topics = parseStudyTopics("صرف ساده | 120 | زیاد\nنحو | 90 | متوسط | صرف ساده، تجوید");
  assert.equal(topics.length, 2);
  assert.equal(topics[0].priority, "زیاد");
  assert.deepEqual(topics[1].prerequisites, ["صرف ساده", "تجوید"]);
});

test("rejects empty, duplicate and out-of-range topics", () => {
  assert.throws(() => parseStudyTopics(" \n "), /حداقل یک درس/);
  assert.throws(() => parseStudyTopics("صرف | 30 | زیاد\nصرف | 45 | کم"), /عنوان تکراری/);
  assert.throws(() => parseStudyTopics("صرف | 5 | زیاد"), /بین ۱۵ تا ۶۰۰۰/);
});

test("prerequisites are placed before dependent topics even when lower priority", () => {
  const topics = parseStudyTopics("نحو | 30 | زیاد | صرف\nصرف | 30 | کم");
  const ordered = orderTopicsByPriorityAndPrerequisites(topics);
  assert.deepEqual(ordered.map((topic) => topic.title), ["صرف", "نحو"]);
});

test("rejects dependency cycles without infinite looping", () => {
  const topics = parseStudyTopics("صرف | 30 | زیاد | نحو\nنحو | 30 | زیاد | صرف");
  assert.throws(() => orderTopicsByPriorityAndPrerequisites(topics), /چرخه/);
});

test("plans avoid existing appointments and keep every session inside the allowed time window", () => {
  const topics = parseStudyTopics("صرف | 80 | زیاد\nنحو | 40 | متوسط");
  const plan = makeStudyPlan({
    topics,
    startDate: "2026-10-31",
    days: 3,
    dailyMinutes: 80,
    sessionMinutes: 40,
    breakMinutes: 10,
    startTime: "20:30",
    endTime: "22:30",
    activeDays: [0, 1, 2, 3, 4, 6],
    existingTasks: [{ date: "2026-10-31", start: "20:30", end: "20:50", status: "pending" }],
  });
  assert.ok(plan.tasks.length > 0);
  for (const task of plan.tasks) {
    assert.ok(task.start >= "20:30");
    assert.ok(task.end <= "22:30");
    assert.ok(!(task.date === "2026-10-31" && task.start < "20:50" && task.end > "20:30"));
  }
  assert.equal(plan.scheduledMinutes, plan.tasks.reduce((sum, task) => sum + task.topicMinutes, 0));
});

test("does not schedule on the excluded Friday and reports unscheduled workload honestly", () => {
  const topics = parseStudyTopics("صرف | 180 | زیاد");
  const plan = makeStudyPlan({
    topics,
    startDate: "2026-10-30",
    days: 1,
    dailyMinutes: 60,
    sessionMinutes: 40,
    startTime: "20:30",
    endTime: "22:30",
    activeDays: [0, 1, 2, 3, 4, 6],
  });
  assert.equal(plan.tasks.length, 0);
  assert.equal(plan.unscheduledMinutes, 180);
});

test("honors the daily study budget and schedules prerequisite sessions first", () => {
  const topics = parseStudyTopics("نحو | 45 | زیاد | صرف\nصرف | 90 | کم");
  const plan = makeStudyPlan({
    topics,
    startDate: "2026-10-31",
    days: 7,
    dailyMinutes: 60,
    sessionMinutes: 40,
    breakMinutes: 10,
    startTime: "20:30",
    endTime: "22:30",
    activeDays: [0, 1, 2, 3, 4, 6],
  });
  const firstNahw = plan.tasks.findIndex((task) => task.topicTitle === "نحو");
  const lastSarf = plan.tasks.map((task) => task.topicTitle).lastIndexOf("صرف");
  assert.ok(firstNahw > lastSarf);
  const minutesByDate = new Map();
  for (const task of plan.tasks) minutesByDate.set(task.date, (minutesByDate.get(task.date) || 0) + task.topicMinutes);
  for (const total of minutesByDate.values()) assert.ok(total <= 60);
});

test("rejects a time window that cannot contain a positive study session", () => {
  const topics = parseStudyTopics("صرف | 30 | زیاد");
  assert.throws(() => makeStudyPlan({
    topics,
    startDate: "2026-10-31",
    days: 1,
    startTime: "20:30",
    endTime: "20:30",
  }), /پایان بازه/);
});
