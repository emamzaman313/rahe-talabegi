from pathlib import Path
import shutil
import sys

repo = Path(sys.argv[1]).resolve()
package = Path(sys.argv[2]).resolve()
auth_path = repo / 'src' / 'hamghadam-auth.js'
client_path = repo / 'src' / 'supabase-client.js'
if not auth_path.is_file() or not client_path.is_file():
    raise SystemExit('Expected src/hamghadam-auth.js and src/supabase-client.js; repository layout differs. No patch applied.')
auth = auth_path.read_text(encoding='utf-8')

def replace_once(source, old, new, name):
    count = source.count(old)
    if count != 1:
        raise SystemExit(f'Patch anchor {name!r} expected once, found {count}. No files changed.')
    return source.replace(old, new, 1)

# Build all in memory first; if the current code differs, fail closed before changing files.
auth = replace_once(auth, "const GATE_ID = 'hg-auth-gate';\n", "const GATE_ID = 'hg-auth-gate';\nconst AUTH_DEADLINE_MS = 20000;\n", 'auth deadline constant')
helper = '''function withDeadline(promise, operation, timeoutMs = AUTH_DEADLINE_MS) {
  let timer;
  return Promise.race([
    Promise.resolve(promise),
    new Promise((_, reject) => {
      timer = setTimeout(() => {
        const error = new Error(`${operation} بیش از حد طول کشید.`);
        error.name = 'TimeoutError';
        reject(error);
      }, timeoutMs);
    }),
  ]).finally(() => clearTimeout(timer));
}

'''
auth = replace_once(auth, 'function getLegacyProfile() {\n', helper + 'function getLegacyProfile() {\n', 'deadline helper insertion')
replacements = [
  ("const { data: response, error } = await supabase.auth.signUp({ email, password, options: { data: { display_name: name } } });", "const { data: response, error } = await withDeadline(\n        supabase.auth.signUp({ email, password, options: { data: { display_name: name } }}),\n        'ثبت‌نام'\n      );", 'signup request'),
  ("const { data: response, error } = await supabase.auth.signInWithPassword({ email, password });", "const { data: response, error } = await withDeadline(\n        supabase.auth.signInWithPassword({ email, password }),\n        'ورود'\n      );", 'login request'),
  ("const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo });", "const { error } = await withDeadline(\n        supabase.auth.resetPasswordForEmail(email, { redirectTo }),\n        'بازیابی رمز عبور'\n      );", 'password reset request'),
  ("const { error } = await supabase.auth.updateUser({ password });", "const { error } = await withDeadline(\n        supabase.auth.updateUser({ password }),\n        'تغییر رمز عبور'\n      );", 'password update request'),
  ("const friendly = /invalid login credentials/i.test(message) ? 'ایمیل یا رمز عبور درست نیست.'\n      : /email not confirmed/i.test(message) ? 'ایمیل هنوز تأیید نشده است؛ صندوق ایمیلت را بررسی کن.'\n      : /user already registered/i.test(message) ? 'این ایمیل قبلاً ثبت شده است؛ وارد حساب شو.'\n      : `عملیات انجام نشد: ${message}`;", "const friendly = error?.name === 'TimeoutError' || /timed out|timeout|deadline/i.test(message)\n      ? 'پاسخ سرور به‌موقع نرسید. اتصال اینترنت را بررسی کن و دوباره تلاش کن.'\n      : /failed to fetch|network|fetch|abort/i.test(message)\n        ? 'ارتباط با سرور برقرار نشد. اینترنت را بررسی کن و دوباره تلاش کن.'\n        : /invalid login credentials/i.test(message) ? 'ایمیل یا رمز عبور درست نیست.'\n        : /email not confirmed/i.test(message) ? 'ایمیل هنوز تأیید نشده است؛ صندوق ایمیلت را بررسی کن.'\n        : /user already registered/i.test(message) ? 'این ایمیل قبلاً ثبت شده است؛ وارد حساب شو.'\n        : `عملیات انجام نشد: ${message}`;", 'friendly timeout/network errors'),
  ("const { error } = await supabase.auth.signOut();", "const { error } = await withDeadline(supabase.auth.signOut(), 'خروج از حساب');", 'logout request'),
  ("void supabase.auth.getSession().then(({ data, error }) => {\n    if (error) setNotice(`خواندن نشست انجام نشد: ${error.message}`, 'error');\n    void acceptSession(data?.session || null);\n  }).catch((error) => setNotice(`اتصال ورود ناموفق بود: ${error?.message || 'خطای شبکه'}`, 'error'));", "void withDeadline(supabase.auth.getSession(), 'بررسی نشست')\n    .then(({ data, error }) => {\n      if (error) setNotice(`خواندن نشست انجام نشد: ${error.message}`, 'error');\n      void acceptSession(data?.session || null);\n    }).catch((error) => {\n      const timedOut = error?.name === 'TimeoutError' || /timed out|timeout|deadline/i.test(String(error?.message || ''));\n      setNotice(timedOut\n        ? 'بررسی اتصال بیش از حد طول کشید. اینترنت را بررسی کن و دوباره تلاش کن.'\n        : `اتصال ورود ناموفق بود: ${error?.message || 'خطای شبکه'}`, 'error');\n    });", 'initial session deadline'),
]
for old, new, name in replacements:
    auth = replace_once(auth, old, new, name)
for rel in ('src/timed-fetch.mjs', 'src/supabase-client.js', 'tests/timed-fetch.test.mjs'):
    if not (package / rel).is_file():
        raise SystemExit(f'Missing package file {rel}; no patch applied.')
# All source anchors validated; writes begin here.
for rel in ('src/timed-fetch.mjs', 'src/supabase-client.js', 'tests/timed-fetch.test.mjs'):
    dest = repo / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(package / rel, dest)
auth_path.write_text(auth, encoding='utf-8')
print('Updated bounded Supabase HTTP requests and auth/session deadlines.')
print('Copied: src/timed-fetch.mjs, src/supabase-client.js, tests/timed-fetch.test.mjs')
