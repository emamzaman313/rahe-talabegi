# وضعیت نهایی بستهٔ تکمیلی هم‌قدم

این سند همراه بسته برای مرزبندی بین «کد اضافه‌شده» و «فعالیت تأییدشدهٔ زنده» است.

## کد بسته

- `src/hamghadam-suite.js` و CSS/core: قابلیت‌های مباحثه، گروه بحث سه‌نفره، چت، تم‌ها، میز کتاب، فلش‌کارت، آزمون، اعلان و تنظیمات.
- `src/hamghadam-admin-console.js` و `admin.html`: پنل مجزا با مجوزهای مبتنی بر `app_metadata` و Edge Function سمت سرور.
- `src/smart-planner.js`, `src/planner-calendar.js` و coreهایشان: افزونه‌های برنامه‌ریز و تقویم برای برنامهٔ فعلی.
- `supabase/migrations/20261027170000_hamghadam_full_suite.sql`: جداول، RPCها، RLS و Storage لازم برای حوزه‌های افزوده‌شده.
- `supabase/functions/hamghadam-admin/index.ts`: عملیات خاص مدیریت Auth و تنظیمات گروه/کانال از سرور با کلید مخفی فقط در محیط سرور.

## وضعیت آزمون

نتایج نهایی باید از گزارش `TEST-REPORT.txt` خوانده شوند. آزمون‌های واحد/ایستای فایل core و assertionهای پوشش schema جایگزین اجرای PostgreSQL، RLS در دیتابیس زنده، مرورگر، موبایل یا Supabase Storage نیستند.

## کار لازم برای عملیاتی‌شدن

1. پشتیبان‌گیری و اجرای review شدهٔ migration جدید روی پروژهٔ Supabase مقصد.
2. deploy تابع `hamghadam-admin` و حفظ کلید service-role در secrets سرور.
3. تعیین امن `super_admin` اولیه با Admin API از محیط مورد اعتماد.
4. اجرای تست‌های زندهٔ دو حساب عادی، مدیر و عضو محدودشده؛ آزمودن چت، گزارش، نقش‌ها، تاریخ مناسبت، پیوست و امتیاز آزمون.
5. تولید و نصب APK پس از موفقیت build، و سپس آزمون روی دستگاه واقعی.

تا پیش از انجام این مراحل، قابلیت‌های نیازمند backend با برچسب «کد آماده؛ نیازمند استقرار و آزمون زنده» تلقی شوند.


## اصلاح رگرسیون build (27 اکتبر 2026)

- رشتهٔ CSS مربوط به `.hg-cal-event time` در `src/planner-calendar.js` بسته شد.
- عبارت `messageComposer` در `src/hamghadam-suite.js` با template literal شروع می‌شود تا HTML فرم به‌عنوان JSX خام تفسیر نشود.
- دو regression test اضافه شد؛ اجرای محلی نهایی 41 تست موفق و 14 بررسی نحوی Node داشت.
- build کامل Vite و ساخت APK در محیط محلی قابل اجرا نبودند؛ نتیجهٔ GitHub Actions پس از آپلود مرجع نهایی build است.
