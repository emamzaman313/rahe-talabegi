import fs from 'node:fs';

const target = process.argv[2] || 'src/hamghadam-auth.js';
if (!fs.existsSync(target)) {
  console.warn(`[Hamghadam] فایل ${target} پیدا نشد؛ وصلهٔ زمان‌پایان ورود به‌صورت خودکار اعمال نشد.`);
  process.exit(0);
}
let source = fs.readFileSync(target, 'utf8');
if (source.includes('function withAuthDeadline(')) {
  console.log('[Hamghadam] وصلهٔ زمان‌پایان از قبل وجود دارد.');
  process.exit(0);
}
const lines = source.split(/\r?\n/);
const escapeLine = lines.findIndex(line => /^\s*const escape\s*=/.test(line) && line.trim().endsWith(';'));
if (escapeLine < 0) {
  console.warn('[Hamghadam] نقطهٔ امن برای درج helper در فایل احراز هویت پیدا نشد؛ فایل دست‌نخورده ماند.');
  process.exit(0);
}
const helper = `\nfunction withAuthDeadline(promise, milliseconds, operation) {\n  let timer;\n  const deadline = new Promise((_, reject) => {\n    timer = setTimeout(() => {\n      const error = new Error(\`${'${operation}'} بیشتر از \${Math.round(milliseconds / 1000)} ثانیه طول کشید. اتصال را بررسی کن؛ پیش از تلاش دوباره، وضعیت درخواست قبلی را در نظر بگیر.\`);\n      error.code = 'HG_AUTH_TIMEOUT';\n      reject(error);\n    }, milliseconds);\n  });\n  return Promise.race([promise, deadline]).finally(() => clearTimeout(timer));\n}\n`;
const offset = lines.slice(0, escapeLine + 1).join('\n').length;
source = source.slice(0, offset) + helper + source.slice(offset);

function matchingParen(text, open) {
  let depth = 0, quote = null, lineComment = false, blockComment = false, escaped = false;
  for (let i = open; i < text.length; i++) {
    const c = text[i], n = text[i + 1];
    if (lineComment) { if (c === '\n') lineComment = false; continue; }
    if (blockComment) { if (c === '*' && n === '/') { blockComment = false; i++; } continue; }
    if (quote) {
      if (escaped) { escaped = false; continue; }
      if (c === '\\') { escaped = true; continue; }
      if (c === quote) quote = null;
      continue;
    }
    if (c === '/' && n === '/') { lineComment = true; i++; continue; }
    if (c === '/' && n === '*') { blockComment = true; i++; continue; }
    if (c === '\'' || c === '"' || c === '`') { quote = c; continue; }
    if (c === '(') depth++;
    else if (c === ')' && --depth === 0) return i;
  }
  return -1;
}

const specs = [
  ['signUp', 15000, 'ثبت‌نام', true],
  ['signInWithPassword', 15000, 'ورود', true],
  ['resetPasswordForEmail', 15000, 'ارسال راهنمای بازیابی', true],
  ['updateUser', 15000, 'تغییر رمز', true],
  ['getSession', 12000, 'بررسی نشست', false],
];
const edits = [];
for (const [method, ms, operation, requireAwait] of specs) {
  const needle = `supabase.auth.${method}(`;
  let from = 0;
  while (true) {
    const idx = source.indexOf(needle, from);
    if (idx < 0) break;
    from = idx + needle.length;
    const prefix = source.slice(Math.max(0, idx - 120), idx);
    if (/withAuthDeadline\(\s*$/.test(prefix)) continue;
    if (requireAwait && !/\bawait\s+$/.test(prefix)) continue;
    const open = idx + needle.length - 1;
    const close = matchingParen(source, open);
    if (close < 0) {
      console.warn(`[Hamghadam] پرانتز ${method} تشخیص داده نشد؛ آن فراخوانی دست‌نخورده ماند.`);
      continue;
    }
    edits.push({ start: idx, end: close + 1, replacement: `withAuthDeadline(${source.slice(idx, close + 1)}, ${ms}, '${operation}')` });
  }
}
for (const edit of edits.sort((a,b) => b.start - a.start)) {
  source = source.slice(0, edit.start) + edit.replacement + source.slice(edit.end);
}
fs.writeFileSync(target, source, 'utf8');
console.log(`[Hamghadam] helper زمان‌پایان افزوده شد؛ ${edits.length} فراخوانی امن‌تر شد. این وصله درخواست شبکه را از راه دور لغو نمی‌کند.`);
