import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(import.meta.dirname, '..');
const sql = fs.readFileSync(path.join(root, 'supabase/migrations/20261026000000_hamghadam_foundation.sql'), 'utf8');

test('personal study data is owner-scoped with RLS', () => {
  for (const table of ['hg_user_preferences','hg_study_tasks','hg_study_notes']) {
    assert.match(sql, new RegExp(`alter table public\\.${table} enable row level security`, 'i'));
    assert.match(sql, new RegExp(`${table}_owner`, 'i'));
  }
});

test('private messages require conversation membership', () => {
  assert.match(sql, /create or replace function public\.hg_is_dm_member/i);
  assert.match(sql, /sender_id\s*=\s*\(select auth\.uid\(\)\)\s+and\s+public\.hg_is_dm_member\(conversation_id\)/i);
  assert.match(sql, /hg_dm_messages_read.*public\.hg_is_dm_member/s);
});

test('group and channel message access is membership-scoped', () => {
  assert.match(sql, /public\.hg_is_group_member\(group_id\)/i);
  assert.match(sql, /public\.hg_is_channel_member\(channel_id\)/i);
  assert.match(sql, /alter table public\.hg_group_messages enable row level security/i);
  assert.match(sql, /alter table public\.hg_channel_posts enable row level security/i);
});

test('moderation and report data have role-scoped access', () => {
  assert.match(sql, /create or replace function public\.hg_is_moderator/i);
  assert.match(sql, /create policy hg_chat_reports_read.*public\.hg_is_moderator/s);
  assert.match(sql, /create policy hg_moderation_actions_admin_insert.*public\.hg_is_moderator/s);
});

test('book uploads use a private bucket capped at 100 MiB', () => {
  assert.match(sql, /values \('hg-user-books','hg-user-books',false,104857600/i);
  assert.match(sql, /storage\.foldername\(name\).*auth\.uid/s);
});

test('browser cannot insert or modify point ledger or audit trail', () => {
  assert.match(sql, /revoke all on table public\.hg_points_ledger from public, anon, authenticated/i);
  assert.match(sql, /revoke all on table public\.hg_audit_events from public, anon, authenticated/i);
});

test('members cannot promote themselves or arbitrarily invite users into groups/channels', () => {
  assert.match(sql, /create policy hg_group_members_add.*hg_can_manage_group/s);
  assert.match(sql, /create policy hg_channel_members_add.*hg_can_manage_channel/s);
  assert.match(sql, /member_role='member'/);
});

test('server service role has explicit grants for server-side modules', () => {
  assert.match(sql, /to service_role/i);
});
