-- هم‌قدم: زیرساخت دادهٔ شخصی و اجتماعی؛ بنیاد سروری مرحله‌ای
-- این migration ساختار و سیاست‌های پایه را ایجاد می‌کند، نه UI کامل همهٔ ماژول‌ها.
-- قبل از اجرا روی دیتابیس واقعی، backup بگیر و فقط روی همان پروژهٔ متصل به اپ اجرا کن.

create or replace function public.hg_is_moderator()
returns boolean
language sql stable security invoker
set search_path = ''
as $$
  select coalesce((auth.jwt() -> 'app_metadata' ->> 'role') in ('admin','support','moderator'), false);
$$;

create or replace function public.hg_touch_updated_at()
returns trigger language plpgsql
set search_path = ''
as $$ begin new.updated_at := pg_catalog.now(); return new; end $$;

-- ترجیحات همگام‌شوندهٔ کاربر (تم و تنظیمات قابل‌همگام‌سازی؛ بدون ثبت دادهٔ حساس).
create table if not exists public.hg_user_preferences (
  user_id uuid primary key references auth.users(id) on delete cascade,
  preferences jsonb not null default '{}'::jsonb check (jsonb_typeof(preferences) = 'object'),
  updated_at timestamptz not null default now()
);
alter table public.hg_user_preferences enable row level security;
drop policy if exists hg_user_preferences_owner on public.hg_user_preferences;
create policy hg_user_preferences_owner on public.hg_user_preferences for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
grant select, insert, update, delete on public.hg_user_preferences to authenticated;
drop trigger if exists hg_user_preferences_touch on public.hg_user_preferences;
create trigger hg_user_preferences_touch before update on public.hg_user_preferences
for each row execute function public.hg_touch_updated_at();

-- برنامهٔ مطالعه و یادداشت‌های خصوصی.
create table if not exists public.hg_study_tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(btrim(title)) between 1 and 160),
  details text not null default '' check (char_length(details) <= 10000),
  subject text not null default '' check (char_length(subject) <= 100),
  priority smallint not null default 3 check (priority between 1 and 5),
  status text not null default 'todo' check (status in ('todo','in_progress','done','skipped')),
  starts_at timestamptz,
  due_at timestamptz,
  duration_minutes integer check (duration_minutes between 5 and 720),
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists hg_study_tasks_owner_due_idx on public.hg_study_tasks(user_id, due_at);
alter table public.hg_study_tasks enable row level security;
drop policy if exists hg_study_tasks_owner on public.hg_study_tasks;
create policy hg_study_tasks_owner on public.hg_study_tasks for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
grant select, insert, update, delete on public.hg_study_tasks to authenticated;
drop trigger if exists hg_study_tasks_touch on public.hg_study_tasks;
create trigger hg_study_tasks_touch before update on public.hg_study_tasks
for each row execute function public.hg_touch_updated_at();

create table if not exists public.hg_study_notes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(btrim(title)) between 1 and 180),
  body text not null default '' check (char_length(body) <= 100000),
  subject text not null default '' check (char_length(subject) <= 100),
  tags text[] not null default '{}',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists hg_study_notes_owner_updated_idx on public.hg_study_notes(user_id, updated_at desc);
alter table public.hg_study_notes enable row level security;
drop policy if exists hg_study_notes_owner on public.hg_study_notes;
create policy hg_study_notes_owner on public.hg_study_notes for all to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
grant select, insert, update, delete on public.hg_study_notes to authenticated;
drop trigger if exists hg_study_notes_touch on public.hg_study_notes;
create trigger hg_study_notes_touch before update on public.hg_study_notes
for each row execute function public.hg_touch_updated_at();

-- پیام خصوصی: اعضا را فقط تابع عضویتِ محدودشده بررسی می‌کند تا RLS بازگشتی نشود.
create table if not exists public.hg_dm_conversations (
  id uuid primary key default gen_random_uuid(),
  created_by uuid not null references auth.users(id) on delete cascade,
  title text not null default 'گفت‌وگوی خصوصی' check (char_length(title) between 1 and 160),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.hg_dm_members (
  conversation_id uuid not null references public.hg_dm_conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  member_role text not null default 'member' check (member_role in ('member','conversation_admin')),
  joined_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);
create or replace function public.hg_is_dm_member(p_conversation_id uuid)
returns boolean language sql stable security definer set search_path = ''
as $$ select exists (select 1 from public.hg_dm_members m where m.conversation_id = p_conversation_id and m.user_id = auth.uid()); $$;
revoke all on function public.hg_is_dm_member(uuid) from public, anon;
grant execute on function public.hg_is_dm_member(uuid) to authenticated;
create or replace function public.hg_add_dm_creator()
returns trigger language plpgsql security definer set search_path = ''
as $$ begin insert into public.hg_dm_members(conversation_id,user_id,member_role) values (new.id,new.created_by,'conversation_admin') on conflict do nothing; return new; end $$;
drop trigger if exists hg_dm_add_creator on public.hg_dm_conversations;
create trigger hg_dm_add_creator after insert on public.hg_dm_conversations for each row execute function public.hg_add_dm_creator();
create table if not exists public.hg_dm_messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.hg_dm_conversations(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(btrim(body)) between 1 and 5000),
  reply_to uuid references public.hg_dm_messages(id) on delete set null,
  edited_at timestamptz,
  deleted_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists hg_dm_messages_thread_idx on public.hg_dm_messages(conversation_id, created_at);
alter table public.hg_dm_conversations enable row level security;
alter table public.hg_dm_members enable row level security;
alter table public.hg_dm_messages enable row level security;
drop policy if exists hg_dm_conversations_read on public.hg_dm_conversations;
create policy hg_dm_conversations_read on public.hg_dm_conversations for select to authenticated using (public.hg_is_dm_member(id) or public.hg_is_moderator());
drop policy if exists hg_dm_conversations_create on public.hg_dm_conversations;
create policy hg_dm_conversations_create on public.hg_dm_conversations for insert to authenticated with check (created_by = (select auth.uid()));
drop policy if exists hg_dm_conversations_update on public.hg_dm_conversations;
create policy hg_dm_conversations_update on public.hg_dm_conversations for update to authenticated using (public.hg_is_dm_member(id)) with check (public.hg_is_dm_member(id));
drop policy if exists hg_dm_members_read on public.hg_dm_members;
create policy hg_dm_members_read on public.hg_dm_members for select to authenticated using (user_id = (select auth.uid()) or public.hg_is_dm_member(conversation_id) or public.hg_is_moderator());
drop policy if exists hg_dm_members_add on public.hg_dm_members;
create policy hg_dm_members_add on public.hg_dm_members for insert to authenticated with check (public.hg_is_dm_member(conversation_id) or user_id = (select auth.uid()) and exists (select 1 from public.hg_dm_conversations c where c.id = conversation_id and c.created_by = (select auth.uid())));
drop policy if exists hg_dm_members_leave on public.hg_dm_members;
create policy hg_dm_members_leave on public.hg_dm_members for delete to authenticated using (user_id = (select auth.uid()) or public.hg_is_moderator());
drop policy if exists hg_dm_messages_read on public.hg_dm_messages;
create policy hg_dm_messages_read on public.hg_dm_messages for select to authenticated using (public.hg_is_dm_member(conversation_id) or public.hg_is_moderator());
drop policy if exists hg_dm_messages_insert on public.hg_dm_messages;
create policy hg_dm_messages_insert on public.hg_dm_messages for insert to authenticated with check (sender_id = (select auth.uid()) and public.hg_is_dm_member(conversation_id));
drop policy if exists hg_dm_messages_edit_own on public.hg_dm_messages;
create policy hg_dm_messages_edit_own on public.hg_dm_messages for update to authenticated using (sender_id = (select auth.uid()) and created_at > now() - interval '10 minutes') with check (sender_id = (select auth.uid()) and public.hg_is_dm_member(conversation_id));
drop policy if exists hg_dm_messages_delete_own on public.hg_dm_messages;
create policy hg_dm_messages_delete_own on public.hg_dm_messages for delete to authenticated using (sender_id = (select auth.uid()) and created_at > now() - interval '10 minutes');
grant select, insert, update, delete on public.hg_dm_conversations, public.hg_dm_members to authenticated;
grant select, insert, delete on public.hg_dm_messages to authenticated;
grant update (body, reply_to, edited_at, deleted_at) on public.hg_dm_messages to authenticated;

-- گروه‌ها و پیام گروهی.
create table if not exists public.hg_groups (
  id uuid primary key default gen_random_uuid(),
  created_by uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(btrim(title)) between 1 and 120),
  description text not null default '' check (char_length(description) <= 2000),
  visibility text not null default 'private' check (visibility in ('public','private')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.hg_group_members (
  group_id uuid not null references public.hg_groups(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  member_role text not null default 'member' check (member_role in ('member','moderator','owner')),
  joined_at timestamptz not null default now(),
  primary key(group_id,user_id)
);
create or replace function public.hg_is_group_member(p_group_id uuid)
returns boolean language sql stable security definer set search_path = ''
as $$ select exists (select 1 from public.hg_group_members m where m.group_id = p_group_id and m.user_id = auth.uid()); $$;
revoke all on function public.hg_is_group_member(uuid) from public, anon;
grant execute on function public.hg_is_group_member(uuid) to authenticated;
create or replace function public.hg_can_manage_group(p_group_id uuid)
returns boolean language sql stable security definer set search_path = ''
as $$ select public.hg_is_moderator() or exists (select 1 from public.hg_group_members m where m.group_id=p_group_id and m.user_id=auth.uid() and m.member_role in ('owner','moderator')); $$;
revoke all on function public.hg_can_manage_group(uuid) from public, anon;
grant execute on function public.hg_can_manage_group(uuid) to authenticated;
create or replace function public.hg_add_group_creator()
returns trigger language plpgsql security definer set search_path = ''
as $$ begin insert into public.hg_group_members(group_id,user_id,member_role) values (new.id,new.created_by,'owner') on conflict do nothing; return new; end $$;
drop trigger if exists hg_groups_add_creator on public.hg_groups;
create trigger hg_groups_add_creator after insert on public.hg_groups for each row execute function public.hg_add_group_creator();
create table if not exists public.hg_group_messages (
  id uuid primary key default gen_random_uuid(),
  group_id uuid not null references public.hg_groups(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(btrim(body)) between 1 and 5000),
  reply_to uuid references public.hg_group_messages(id) on delete set null,
  edited_at timestamptz,
  deleted_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists hg_group_messages_timeline_idx on public.hg_group_messages(group_id,created_at);
alter table public.hg_groups enable row level security;
alter table public.hg_group_members enable row level security;
alter table public.hg_group_messages enable row level security;
drop policy if exists hg_groups_read on public.hg_groups;
create policy hg_groups_read on public.hg_groups for select to authenticated using (visibility='public' or created_by=(select auth.uid()) or public.hg_is_group_member(id) or public.hg_is_moderator());
drop policy if exists hg_groups_create on public.hg_groups;
create policy hg_groups_create on public.hg_groups for insert to authenticated with check (created_by=(select auth.uid()));
drop policy if exists hg_groups_update on public.hg_groups;
create policy hg_groups_update on public.hg_groups for update to authenticated using (created_by=(select auth.uid()) or public.hg_is_moderator()) with check (created_by=(select auth.uid()) or public.hg_is_moderator());
drop policy if exists hg_groups_delete on public.hg_groups;
create policy hg_groups_delete on public.hg_groups for delete to authenticated using (created_by=(select auth.uid()) or public.hg_is_moderator());
drop policy if exists hg_group_members_read on public.hg_group_members;
create policy hg_group_members_read on public.hg_group_members for select to authenticated using (user_id=(select auth.uid()) or public.hg_is_group_member(group_id) or public.hg_is_moderator());
drop policy if exists hg_group_members_add on public.hg_group_members;
create policy hg_group_members_add on public.hg_group_members for insert to authenticated with check (public.hg_can_manage_group(group_id) or (user_id=(select auth.uid()) and member_role='member' and exists(select 1 from public.hg_groups g where g.id=group_id and g.visibility='public')));
drop policy if exists hg_group_members_remove on public.hg_group_members;
create policy hg_group_members_remove on public.hg_group_members for delete to authenticated using (user_id=(select auth.uid()) or public.hg_is_moderator() or exists(select 1 from public.hg_groups g where g.id=group_id and g.created_by=(select auth.uid())));
drop policy if exists hg_group_messages_read on public.hg_group_messages;
create policy hg_group_messages_read on public.hg_group_messages for select to authenticated using (public.hg_is_group_member(group_id) or public.hg_is_moderator());
drop policy if exists hg_group_messages_insert on public.hg_group_messages;
create policy hg_group_messages_insert on public.hg_group_messages for insert to authenticated with check (sender_id=(select auth.uid()) and public.hg_is_group_member(group_id));
drop policy if exists hg_group_messages_edit_own on public.hg_group_messages;
create policy hg_group_messages_edit_own on public.hg_group_messages for update to authenticated using (sender_id=(select auth.uid()) and created_at > now()-interval '10 minutes' and public.hg_is_group_member(group_id)) with check (sender_id=(select auth.uid()) and public.hg_is_group_member(group_id));
drop policy if exists hg_group_messages_delete_own on public.hg_group_messages;
create policy hg_group_messages_delete_own on public.hg_group_messages for delete to authenticated using (sender_id=(select auth.uid()) and created_at > now()-interval '10 minutes' and public.hg_is_group_member(group_id));
grant select, insert, update, delete on public.hg_groups, public.hg_group_members to authenticated;
grant select, insert, delete on public.hg_group_messages to authenticated;
grant update (body, reply_to, edited_at, deleted_at) on public.hg_group_messages to authenticated;
drop trigger if exists hg_groups_touch on public.hg_groups;
create trigger hg_groups_touch before update on public.hg_groups for each row execute function public.hg_touch_updated_at();

-- کانال‌ها: عمومی یا خصوصی؛ نقش مالک داخل کانال مجوز global admin محسوب نمی‌شود.
create table if not exists public.hg_channels (
  id uuid primary key default gen_random_uuid(),
  created_by uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(btrim(title)) between 1 and 120),
  description text not null default '' check (char_length(description) <= 2000),
  visibility text not null default 'private' check (visibility in ('public','private')),
  post_mode text not null default 'broadcast' check (post_mode in ('broadcast','discussion')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.hg_channel_members (
  channel_id uuid not null references public.hg_channels(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  member_role text not null default 'member' check (member_role in ('member','editor','owner')),
  joined_at timestamptz not null default now(),
  primary key(channel_id,user_id)
);
create or replace function public.hg_is_channel_member(p_channel_id uuid)
returns boolean language sql stable security definer set search_path = ''
as $$ select exists (select 1 from public.hg_channel_members m where m.channel_id = p_channel_id and m.user_id = auth.uid()); $$;
revoke all on function public.hg_is_channel_member(uuid) from public, anon;
grant execute on function public.hg_is_channel_member(uuid) to authenticated;
create or replace function public.hg_can_manage_channel(p_channel_id uuid)
returns boolean language sql stable security definer set search_path = ''
as $$ select public.hg_is_moderator() or exists (select 1 from public.hg_channel_members m where m.channel_id=p_channel_id and m.user_id=auth.uid() and m.member_role in ('owner','editor')); $$;
revoke all on function public.hg_can_manage_channel(uuid) from public, anon;
grant execute on function public.hg_can_manage_channel(uuid) to authenticated;
create or replace function public.hg_add_channel_creator()
returns trigger language plpgsql security definer set search_path = ''
as $$ begin insert into public.hg_channel_members(channel_id,user_id,member_role) values (new.id,new.created_by,'owner') on conflict do nothing; return new; end $$;
drop trigger if exists hg_channels_add_creator on public.hg_channels;
create trigger hg_channels_add_creator after insert on public.hg_channels for each row execute function public.hg_add_channel_creator();
create table if not exists public.hg_channel_posts (
  id uuid primary key default gen_random_uuid(),
  channel_id uuid not null references public.hg_channels(id) on delete cascade,
  author_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(btrim(body)) between 1 and 10000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists hg_channel_posts_timeline_idx on public.hg_channel_posts(channel_id,created_at desc);
alter table public.hg_channels enable row level security;
alter table public.hg_channel_members enable row level security;
alter table public.hg_channel_posts enable row level security;
drop policy if exists hg_channels_read on public.hg_channels;
create policy hg_channels_read on public.hg_channels for select to authenticated using (visibility='public' or created_by=(select auth.uid()) or public.hg_is_channel_member(id) or public.hg_is_moderator());
drop policy if exists hg_channels_create on public.hg_channels;
create policy hg_channels_create on public.hg_channels for insert to authenticated with check (created_by=(select auth.uid()));
drop policy if exists hg_channels_update on public.hg_channels;
create policy hg_channels_update on public.hg_channels for update to authenticated using (created_by=(select auth.uid()) or public.hg_is_moderator()) with check (created_by=(select auth.uid()) or public.hg_is_moderator());
drop policy if exists hg_channels_delete on public.hg_channels;
create policy hg_channels_delete on public.hg_channels for delete to authenticated using (created_by=(select auth.uid()) or public.hg_is_moderator());
drop policy if exists hg_channel_members_read on public.hg_channel_members;
create policy hg_channel_members_read on public.hg_channel_members for select to authenticated using (user_id=(select auth.uid()) or public.hg_is_channel_member(channel_id) or public.hg_is_moderator());
drop policy if exists hg_channel_members_add on public.hg_channel_members;
create policy hg_channel_members_add on public.hg_channel_members for insert to authenticated with check (public.hg_can_manage_channel(channel_id) or (user_id=(select auth.uid()) and member_role='member' and exists(select 1 from public.hg_channels c where c.id=channel_id and c.visibility='public')));
drop policy if exists hg_channel_members_remove on public.hg_channel_members;
create policy hg_channel_members_remove on public.hg_channel_members for delete to authenticated using (user_id=(select auth.uid()) or public.hg_is_moderator() or exists(select 1 from public.hg_channels c where c.id=channel_id and c.created_by=(select auth.uid())));
drop policy if exists hg_channel_posts_read on public.hg_channel_posts;
create policy hg_channel_posts_read on public.hg_channel_posts for select to authenticated using (public.hg_is_channel_member(channel_id) or public.hg_is_moderator() or exists(select 1 from public.hg_channels c where c.id=channel_id and c.visibility='public'));
drop policy if exists hg_channel_posts_insert on public.hg_channel_posts;
create policy hg_channel_posts_insert on public.hg_channel_posts for insert to authenticated with check (author_id=(select auth.uid()) and exists(select 1 from public.hg_channels c where c.id=channel_id and (c.created_by=(select auth.uid()) or (c.post_mode='discussion' and public.hg_is_channel_member(c.id)))));
drop policy if exists hg_channel_posts_update_own on public.hg_channel_posts;
create policy hg_channel_posts_update_own on public.hg_channel_posts for update to authenticated using (author_id=(select auth.uid()) and created_at > now()-interval '10 minutes') with check (author_id=(select auth.uid()) and (public.hg_is_channel_member(channel_id) or exists(select 1 from public.hg_channels c where c.id=channel_id and c.created_by=(select auth.uid()))));
drop policy if exists hg_channel_posts_delete_own on public.hg_channel_posts;
create policy hg_channel_posts_delete_own on public.hg_channel_posts for delete to authenticated using (author_id=(select auth.uid()) and created_at > now()-interval '10 minutes');
grant select, insert, update, delete on public.hg_channels, public.hg_channel_members to authenticated;
grant select, insert, delete on public.hg_channel_posts to authenticated;
grant update (body) on public.hg_channel_posts to authenticated;
drop trigger if exists hg_channels_touch on public.hg_channels;
create trigger hg_channels_touch before update on public.hg_channels for each row execute function public.hg_touch_updated_at();
drop trigger if exists hg_channel_posts_touch on public.hg_channel_posts;
create trigger hg_channel_posts_touch before update on public.hg_channel_posts for each row execute function public.hg_touch_updated_at();

-- کتاب/فایل متعلق به کاربر: Storage bucket سقف ۱۰۰ MiB را در سرور اعمال می‌کند.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('hg-user-books','hg-user-books',false,104857600,array['application/pdf','application/epub+zip','text/plain','application/zip'])
on conflict (id) do update set public=false, file_size_limit=104857600,
  allowed_mime_types=array['application/pdf','application/epub+zip','text/plain','application/zip'];
create table if not exists public.hg_book_assets (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(btrim(title)) between 1 and 180),
  description text not null default '' check (char_length(description) <= 2000),
  storage_path text not null unique,
  mime_type text not null,
  file_size_bytes bigint not null check (file_size_bytes between 1 and 104857600),
  visibility text not null default 'private' check (visibility in ('private','public')),
  moderation_status text not null default 'pending' check (moderation_status in ('pending','published','rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (storage_path like owner_id::text || '/%')
);
alter table public.hg_book_assets enable row level security;
drop policy if exists hg_book_assets_read on public.hg_book_assets;
create policy hg_book_assets_read on public.hg_book_assets for select to authenticated using (owner_id=(select auth.uid()) or (visibility='public' and moderation_status='published') or public.hg_is_moderator());
drop policy if exists hg_book_assets_create on public.hg_book_assets;
create policy hg_book_assets_create on public.hg_book_assets for insert to authenticated with check (owner_id=(select auth.uid()) and storage_path like (select auth.uid())::text || '/%' and moderation_status='pending');
drop policy if exists hg_book_assets_update_pending on public.hg_book_assets;
create policy hg_book_assets_update_pending on public.hg_book_assets for update to authenticated using (owner_id=(select auth.uid()) and moderation_status='pending') with check (owner_id=(select auth.uid()) and moderation_status='pending');
drop policy if exists hg_book_assets_moderate on public.hg_book_assets;
create policy hg_book_assets_moderate on public.hg_book_assets for update to authenticated using (public.hg_is_moderator()) with check (public.hg_is_moderator());
drop policy if exists hg_book_assets_delete on public.hg_book_assets;
create policy hg_book_assets_delete on public.hg_book_assets for delete to authenticated using (owner_id=(select auth.uid()) or public.hg_is_moderator());
grant select, insert, update, delete on public.hg_book_assets to authenticated;
drop trigger if exists hg_book_assets_touch on public.hg_book_assets;
create trigger hg_book_assets_touch before update on public.hg_book_assets for each row execute function public.hg_touch_updated_at();
drop policy if exists hg_user_books_read_own_folder on storage.objects;
create policy hg_user_books_read_own_folder on storage.objects for select to authenticated using (bucket_id='hg-user-books' and (storage.foldername(name))[1]=(select auth.uid())::text);
drop policy if exists hg_user_books_insert_own_folder on storage.objects;
create policy hg_user_books_insert_own_folder on storage.objects for insert to authenticated with check (bucket_id='hg-user-books' and (storage.foldername(name))[1]=(select auth.uid())::text);
drop policy if exists hg_user_books_update_own_folder on storage.objects;
create policy hg_user_books_update_own_folder on storage.objects for update to authenticated using (bucket_id='hg-user-books' and (storage.foldername(name))[1]=(select auth.uid())::text) with check (bucket_id='hg-user-books' and (storage.foldername(name))[1]=(select auth.uid())::text);
drop policy if exists hg_user_books_delete_own_folder on storage.objects;
create policy hg_user_books_delete_own_folder on storage.objects for delete to authenticated using (bucket_id='hg-user-books' and (storage.foldername(name))[1]=(select auth.uid())::text);

-- گزارش تخلف و سابقهٔ اقدام مدیریتی؛ هیچ کاربر عادی گزارش‌های دیگران را نمی‌خواند.
create table if not exists public.hg_chat_reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references auth.users(id) on delete cascade,
  target_type text not null check (target_type in ('public_chat','private_message','group_message','channel_post','profile')),
  target_id uuid not null,
  reason text not null check (char_length(btrim(reason)) between 2 and 120),
  details text not null default '' check (char_length(details) <= 3000),
  status text not null default 'open' check (status in ('open','reviewing','resolved','rejected')),
  assigned_to uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists hg_chat_reports_status_created_idx on public.hg_chat_reports(status,created_at desc);
alter table public.hg_chat_reports enable row level security;
drop policy if exists hg_chat_reports_read on public.hg_chat_reports;
create policy hg_chat_reports_read on public.hg_chat_reports for select to authenticated using (reporter_id=(select auth.uid()) or public.hg_is_moderator());
drop policy if exists hg_chat_reports_create on public.hg_chat_reports;
create policy hg_chat_reports_create on public.hg_chat_reports for insert to authenticated with check (reporter_id=(select auth.uid()) and status='open' and assigned_to is null);
drop policy if exists hg_chat_reports_moderate on public.hg_chat_reports;
create policy hg_chat_reports_moderate on public.hg_chat_reports for update to authenticated using (public.hg_is_moderator()) with check (public.hg_is_moderator());
grant select, insert, update on public.hg_chat_reports to authenticated;
drop trigger if exists hg_chat_reports_touch on public.hg_chat_reports;
create trigger hg_chat_reports_touch before update on public.hg_chat_reports for each row execute function public.hg_touch_updated_at();

create table if not exists public.hg_moderation_actions (
  id uuid primary key default gen_random_uuid(),
  moderator_id uuid not null references auth.users(id) on delete restrict,
  target_user_id uuid references auth.users(id) on delete set null,
  target_type text not null check (target_type in ('user','message','group','channel','book','report')),
  target_id uuid,
  action text not null check (action in ('warn','mute','ban','unban','hide','restore','close_report','publish_book','reject_book')),
  reason text not null check (char_length(btrim(reason)) between 2 and 1000),
  expires_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.hg_moderation_actions enable row level security;
drop policy if exists hg_moderation_actions_admin_read on public.hg_moderation_actions;
create policy hg_moderation_actions_admin_read on public.hg_moderation_actions for select to authenticated using (public.hg_is_moderator());
drop policy if exists hg_moderation_actions_admin_insert on public.hg_moderation_actions;
create policy hg_moderation_actions_admin_insert on public.hg_moderation_actions for insert to authenticated with check (public.hg_is_moderator() and moderator_id=(select auth.uid()));
grant select, insert on public.hg_moderation_actions to authenticated;

-- اطلاعیه‌ها و اعلان‌های کاربر. امتیازها و audit فقط از مسیر سرور قابل ثبت‌اند.
create table if not exists public.hg_announcements (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references auth.users(id) on delete restrict,
  title text not null check (char_length(btrim(title)) between 1 and 180),
  body text not null check (char_length(btrim(body)) between 1 and 12000),
  status text not null default 'draft' check (status in ('draft','published','archived')),
  audience jsonb not null default '{"type":"all"}'::jsonb check (jsonb_typeof(audience)='object'),
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.hg_announcements enable row level security;
drop policy if exists hg_announcements_read on public.hg_announcements;
create policy hg_announcements_read on public.hg_announcements for select to authenticated using ((status='published' and (published_at is null or published_at <= now())) or public.hg_is_moderator());
drop policy if exists hg_announcements_admin_insert on public.hg_announcements;
create policy hg_announcements_admin_insert on public.hg_announcements for insert to authenticated with check (public.hg_is_moderator() and author_id=(select auth.uid()));
drop policy if exists hg_announcements_admin_update on public.hg_announcements;
create policy hg_announcements_admin_update on public.hg_announcements for update to authenticated using (public.hg_is_moderator()) with check (public.hg_is_moderator());
drop policy if exists hg_announcements_admin_delete on public.hg_announcements;
create policy hg_announcements_admin_delete on public.hg_announcements for delete to authenticated using (public.hg_is_moderator());
grant select, insert, update, delete on public.hg_announcements to authenticated;
drop trigger if exists hg_announcements_touch on public.hg_announcements;
create trigger hg_announcements_touch before update on public.hg_announcements for each row execute function public.hg_touch_updated_at();

create table if not exists public.hg_notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (char_length(kind) between 1 and 60),
  title text not null check (char_length(btrim(title)) between 1 and 160),
  body text not null default '' check (char_length(body) <= 2000),
  link_path text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists hg_notifications_owner_idx on public.hg_notifications(user_id,created_at desc);
alter table public.hg_notifications enable row level security;
drop policy if exists hg_notifications_read_own on public.hg_notifications;
create policy hg_notifications_read_own on public.hg_notifications for select to authenticated using (user_id=(select auth.uid()));
drop policy if exists hg_notifications_update_read_own on public.hg_notifications;
create policy hg_notifications_update_read_own on public.hg_notifications for update to authenticated using (user_id=(select auth.uid())) with check (user_id=(select auth.uid()));
grant select on public.hg_notifications to authenticated;
grant update (read_at) on public.hg_notifications to authenticated;

create table if not exists public.hg_points_ledger (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  event_type text not null check (char_length(event_type) between 1 and 80),
  points integer not null check (points between -100000 and 100000),
  reference_id uuid,
  note text not null default '' check (char_length(note) <= 500),
  created_at timestamptz not null default now()
);

create index if not exists hg_points_ledger_user_idx on public.hg_points_ledger(user_id,created_at desc);
alter table public.hg_points_ledger enable row level security;
drop policy if exists hg_points_ledger_read_own on public.hg_points_ledger;
create policy hg_points_ledger_read_own on public.hg_points_ledger for select to authenticated using (user_id=(select auth.uid()) or public.hg_is_moderator());
revoke all on table public.hg_points_ledger from public, anon, authenticated;
grant select on public.hg_points_ledger to authenticated;

create table if not exists public.hg_audit_events (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references auth.users(id) on delete set null,
  action text not null check (char_length(action) between 1 and 100),
  target_type text,
  target_id uuid,
  metadata jsonb not null default '{}'::jsonb check (jsonb_typeof(metadata)='object'),
  created_at timestamptz not null default now()
);
create index if not exists hg_audit_events_created_idx on public.hg_audit_events(created_at desc);
alter table public.hg_audit_events enable row level security;
drop policy if exists hg_audit_events_admin_read on public.hg_audit_events;
create policy hg_audit_events_admin_read on public.hg_audit_events for select to authenticated using (public.hg_is_moderator());
revoke all on table public.hg_audit_events from public, anon, authenticated;
grant select on public.hg_audit_events to authenticated;

-- Edge Functionهای سرور برای تکمیل مرحله‌های بعدی فقط از service_role استفاده کنند.
grant all on table public.hg_user_preferences, public.hg_study_tasks, public.hg_study_notes,
  public.hg_dm_conversations, public.hg_dm_members, public.hg_dm_messages,
  public.hg_groups, public.hg_group_members, public.hg_group_messages,
  public.hg_channels, public.hg_channel_members, public.hg_channel_posts,
  public.hg_book_assets, public.hg_chat_reports, public.hg_moderation_actions,
  public.hg_announcements, public.hg_notifications, public.hg_points_ledger, public.hg_audit_events
  to service_role;

-- Edge Functionهای سرور فقط از service_role استفاده کنند.
revoke all on function public.hg_add_dm_creator() from public, anon, authenticated;
revoke all on function public.hg_add_group_creator() from public, anon, authenticated;
revoke all on function public.hg_add_channel_creator() from public, anon, authenticated;
revoke all on function public.hg_touch_updated_at() from public, anon, authenticated;
