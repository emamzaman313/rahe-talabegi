$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$repoRoot = (Get-Location).Path
$packageRoot = $PSScriptRoot
$payloadRoot = Join-Path $packageRoot 'payload'
foreach ($required in @('package.json','index.html','src/support-chat.js','src/supabase-client.js')) {
  if (-not (Test-Path (Join-Path $repoRoot $required))) {
    throw "فایل لازم پیدا نشد: $required — نصب از ریشهٔ مخزن rahe-talabegi اجرا نشده یا ساختار مخزن تغییر کرده است."
  }
}
if (-not (Test-Path (Join-Path $repoRoot 'src/hamghadam-auth.js'))) {
  Write-Warning 'src/hamghadam-auth.js پیدا نشد؛ اصلاح زمان‌پایان ورود رد می‌شود و در گزارش باقی می‌ماند.'
}

$indexPath = Join-Path $repoRoot 'index.html'
$index = [System.IO.File]::ReadAllText($indexPath, [System.Text.Encoding]::UTF8)
if (-not $index.Contains('</body>')) { throw 'نقطهٔ </body> در index.html پیدا نشد؛ نصب برای جلوگیری از خراب‌کردن برنامه متوقف شد.' }
$supportPath = Join-Path $repoRoot 'src/support-chat.js'
$support = [System.IO.File]::ReadAllText($supportPath, [System.Text.Encoding]::UTF8)
if (-not $support.Contains("import './support-chat.css';") -and -not $support.Contains("import './ai-assistant.js';")) {
  throw 'نقطهٔ اتصال AI در src/support-chat.js پیدا نشد؛ نصب پیش از تغییر فایل‌ها متوقف شد.'
}

$backupRoot = $null
if (-not [string]::IsNullOrWhiteSpace($env:RUNNER_TEMP)) {
  $backupRoot = Join-Path $repoRoot (".hamghadam-backup-before-phase1/" + (Get-Date -Format 'yyyyMMdd-HHmmss'))
} else {
  $backupRoot = Join-Path $repoRoot (".hamghadam-backup-before-phase1/" + (Get-Date -Format 'yyyyMMdd-HHmmss'))
}

# Preflight every payload path before any copy operation.
$files = @(Get-ChildItem -LiteralPath $payloadRoot -File -Recurse)
if ($files.Count -lt 8) { throw "بسته ناقص به نظر می‌رسد: فقط $($files.Count) فایل قابل نصب پیدا شد." }
foreach ($file in $files) {
  $relative = $file.FullName.Substring($payloadRoot.Length).TrimStart([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
  if ([IO.Path]::IsPathRooted($relative) -or $relative.Split([char[]]@('/','\')) -contains '..') { throw "مسیر ناامن در بسته: $relative" }
}

# Preserve existing files before updating any of them.
foreach ($file in $files) {
  $relative = $file.FullName.Substring($payloadRoot.Length).TrimStart([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
  $destination = Join-Path $repoRoot $relative
  if (Test-Path $destination) {
    $backup = Join-Path $backupRoot $relative
    New-Item -ItemType Directory -Path (Split-Path -Parent $backup) -Force | Out-Null
    Copy-Item -LiteralPath $destination -Destination $backup -Force
  }
  New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
  Copy-Item -LiteralPath $file.FullName -Destination $destination -Force
}
Write-Host "Payload files installed: $($files.Count). Backup location: $backupRoot" -ForegroundColor Green

# Connect the AI module to the existing support module without replacing its logic.
$support = [System.IO.File]::ReadAllText($supportPath, [System.Text.Encoding]::UTF8)
if (-not $support.Contains("import './ai-assistant.js';")) {
  $anchor = "import './support-chat.css';"
  if (-not $support.Contains($anchor)) { throw 'فایل‌ها کپی شدند، اما نقطهٔ اتصال AI تغییر کرده است؛ workflow باید شکست بخورد و commit انجام نشود.' }
  $support = $support.Replace($anchor, "$anchor`nimport './ai-assistant.js';")
  [System.IO.File]::WriteAllText($supportPath, $support, [System.Text.UTF8Encoding]::new($false))
}

# Connect public chat as a module only once.
$index = [System.IO.File]::ReadAllText($indexPath, [System.Text.Encoding]::UTF8)
if (-not $index.Contains('public-chat.js')) {
  $tag = '<script type="module" src="./src/public-chat.js"></script>'
  $pos = $index.LastIndexOf('</body>', [StringComparison]::OrdinalIgnoreCase)
  if ($pos -lt 0) { throw 'نقطهٔ اتصال گفت‌وگوی عمومی پیدا نشد؛ workflow باید شکست بخورد.' }
  $index = $index.Insert($pos, "$tag`n")
  [System.IO.File]::WriteAllText($indexPath, $index, [System.Text.UTF8Encoding]::new($false))
}

# Apply bounded auth waits if the current source still matches the known safe anchor.
$authPatch = Join-Path $repoRoot 'scripts/apply-auth-timeout-patch.mjs'
$authFile = Join-Path $repoRoot 'src/hamghadam-auth.js'
if ((Test-Path $authPatch) -and (Test-Path $authFile)) {
  & node $authPatch $authFile
  if ($LASTEXITCODE -ne 0) { throw 'وصلهٔ زمان‌پایان ورود ناموفق بود؛ workflow باید شکست بخورد.' }
}

Write-Host ''
Write-Host 'نصب فایل‌های افزوده انجام شد؛ migrationهای SQL هنوز روی Supabase اجرا نشده‌اند و Edge Function باید جداگانه deploy و secret آن تنظیم شود.' -ForegroundColor Cyan
